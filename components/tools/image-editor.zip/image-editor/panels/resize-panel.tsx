"use client";

import { Maximize2, Lock, Unlock } from "lucide-react";

interface ResizePanelProps {
  width: number;
  height: number;
  keepAspectRatio: boolean;

  onWidthChange: (value: number) => void;
  onHeightChange: (value: number) => void;

  onToggleAspectRatio: () => void;

  onResize: () => void;
}

export function ResizePanel({
  width,
  height,
  keepAspectRatio,
  onWidthChange,
  onHeightChange,
  onToggleAspectRatio,
  onResize,
}: ResizePanelProps) {
  return (
    <div className="rounded-2xl border bg-card p-6 shadow-sm">

      {/* Header */}

      <div className="mb-6 flex items-center gap-3">

        <div className="rounded-xl bg-primary/10 p-2">
          <Maximize2 className="h-5 w-5 text-primary" />
        </div>

        <div>
          <h3 className="text-lg font-bold">
            Resize Image
          </h3>

          <p className="text-sm text-muted-foreground">
            Change image dimensions without losing quality.
          </p>
        </div>

      </div>

      {/* Width */}

      <div className="mb-4">

        <label className="mb-2 block text-sm font-medium">
          Width (px)
        </label>

        <input
          type="number"
          value={width}
          onChange={(e) =>
            onWidthChange(Number(e.target.value))
          }
          className="w-full rounded-xl border bg-background px-4 py-3 outline-none transition focus:border-primary"
        />

      </div>

      {/* Height */}

      <div className="mb-5">

        <label className="mb-2 block text-sm font-medium">
          Height (px)
        </label>

        <input
          type="number"
          value={height}
          onChange={(e) =>
            onHeightChange(Number(e.target.value))
          }
          className="w-full rounded-xl border bg-background px-4 py-3 outline-none transition focus:border-primary"
        />

      </div>

      {/* Aspect Ratio */}

      <button
        onClick={onToggleAspectRatio}
        className="mb-6 flex w-full items-center justify-center gap-2 rounded-xl border px-4 py-3 transition hover:bg-muted"
      >
        {keepAspectRatio ? (
          <>
            <Lock className="h-4 w-4" />
            Keep Aspect Ratio
          </>
        ) : (
          <>
            <Unlock className="h-4 w-4" />
            Unlock Aspect Ratio
          </>
        )}
      </button>

      {/* Quick Resize */}

      <div className="mb-6">

        <p className="mb-3 text-sm font-medium">
          Quick Resize
        </p>

        <div className="grid grid-cols-2 gap-3">

          {[25, 50, 75, 100].map((size) => (
            <button
              key={size}
              className="rounded-xl border px-4 py-3 text-sm font-medium transition hover:bg-muted"
            >
              {size}%
            </button>
          ))}

        </div>

      </div>

      {/* Apply */}

      <button
        onClick={onResize}
        className="w-full rounded-xl bg-primary px-4 py-3 font-semibold text-primary-foreground transition hover:opacity-90"
      >
        Apply Resize
      </button>

    </div>
  );
}