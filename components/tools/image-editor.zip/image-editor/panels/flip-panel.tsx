"use client";

import {
  FlipHorizontal,
  FlipVertical,
  RefreshCw,
} from "lucide-react";

interface FlipPanelProps {
  isFlippedHorizontal: boolean;
  isFlippedVertical: boolean;

  onFlipHorizontal: () => void;
  onFlipVertical: () => void;
  onReset: () => void;
}

export function FlipPanel({
  isFlippedHorizontal,
  isFlippedVertical,
  onFlipHorizontal,
  onFlipVertical,
  onReset,
}: FlipPanelProps) {
  return (
    <div className="rounded-2xl border bg-card p-6 shadow-sm">

      {/* Header */}

      <div className="mb-6">

        <h3 className="text-lg font-bold">
          Flip Image
        </h3>

        <p className="text-sm text-muted-foreground">
          Flip your image horizontally or vertically.
        </p>

      </div>

      {/* Current Status */}

      <div className="mb-6 rounded-xl bg-muted/40 p-4">

        <div className="flex items-center justify-between">

          <span className="text-sm text-muted-foreground">
            Horizontal
          </span>

          <span className="font-semibold">
            {isFlippedHorizontal
              ? "Flipped"
              : "Normal"}
          </span>

        </div>

        <div className="mt-3 flex items-center justify-between">

          <span className="text-sm text-muted-foreground">
            Vertical
          </span>

          <span className="font-semibold">
            {isFlippedVertical
              ? "Flipped"
              : "Normal"}
          </span>

        </div>

      </div>

      {/* Buttons */}

      <div className="grid grid-cols-2 gap-3">

        <button
          onClick={onFlipHorizontal}
          className="flex items-center justify-center gap-2 rounded-xl border px-4 py-3 transition hover:bg-muted"
        >
          <FlipHorizontal className="h-5 w-5" />
          Horizontal
        </button>

        <button
          onClick={onFlipVertical}
          className="flex items-center justify-center gap-2 rounded-xl border px-4 py-3 transition hover:bg-muted"
        >
          <FlipVertical className="h-5 w-5" />
          Vertical
        </button>

      </div>

      {/* Reset */}

      <button
        onClick={onReset}
        className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 font-semibold text-primary-foreground transition hover:opacity-90"
      >
        <RefreshCw className="h-4 w-4" />
        Reset Flip
      </button>

    </div>
  );
}