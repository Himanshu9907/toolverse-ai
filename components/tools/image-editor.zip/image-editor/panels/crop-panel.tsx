"use client";

import { Crop } from "lucide-react";

interface CropPanelProps {
  aspectRatio: string;
  onAspectRatioChange: (value: string) => void;
  onApplyCrop: () => void;
}

const ratios = [
  { label: "Free", value: "free" },
  { label: "1 : 1", value: "1:1" },
  { label: "4 : 3", value: "4:3" },
  { label: "16 : 9", value: "16:9" },
  { label: "3 : 2", value: "3:2" },
  { label: "9 : 16", value: "9:16" },
];

export function CropPanel({
  aspectRatio,
  onAspectRatioChange,
  onApplyCrop,
}: CropPanelProps) {
  return (
    <div className="rounded-2xl border bg-card p-6 shadow-sm">

      <div className="mb-6 flex items-center gap-3">

        <div className="rounded-xl bg-primary/10 p-2">
          <Crop className="h-5 w-5 text-primary" />
        </div>

        <div>
          <h3 className="text-lg font-bold">
            Crop Image
          </h3>

          <p className="text-sm text-muted-foreground">
            Choose an aspect ratio before cropping.
          </p>
        </div>

      </div>

      <label className="mb-3 block text-sm font-medium">
        Aspect Ratio
      </label>

      <div className="grid grid-cols-2 gap-3">

        {ratios.map((ratio) => (
          <button
            key={ratio.value}
            onClick={() =>
              onAspectRatioChange(ratio.value)
            }
            className={`rounded-xl border px-4 py-3 text-sm font-medium transition

              ${
                aspectRatio === ratio.value
                  ? "border-primary bg-primary text-primary-foreground"
                  : "hover:bg-muted"
              }`}
          >
            {ratio.label}
          </button>
        ))}

      </div>

      <button
        onClick={onApplyCrop}
        className="mt-6 w-full rounded-xl bg-primary px-4 py-3 font-semibold text-primary-foreground transition hover:opacity-90"
      >
        Apply Crop
      </button>

    </div>
  );
}