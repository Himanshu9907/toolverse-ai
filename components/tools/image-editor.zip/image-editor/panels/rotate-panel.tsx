"use client";

import {
  RotateCcw,
  RotateCw,
  RefreshCw,
} from "lucide-react";

interface RotatePanelProps {
  rotation: number;

  onRotateLeft: () => void;
  onRotateRight: () => void;

  onRotate180: () => void;
  onReset: () => void;
}

export function RotatePanel({
  rotation,
  onRotateLeft,
  onRotateRight,
  onRotate180,
  onReset,
}: RotatePanelProps) {
  return (
    <div className="rounded-2xl border bg-card p-6 shadow-sm">

      {/* Header */}

      <div className="mb-6">

        <h3 className="text-lg font-bold">
          Rotate Image
        </h3>

        <p className="text-sm text-muted-foreground">
          Rotate your image with one click.
        </p>

      </div>

      {/* Current Rotation */}

      <div className="mb-6 rounded-xl bg-muted/40 p-4 text-center">

        <p className="text-sm text-muted-foreground">
          Current Rotation
        </p>

        <p className="mt-2 text-3xl font-bold">
          {rotation}°
        </p>

      </div>

      {/* Rotate Left / Right */}

      <div className="grid grid-cols-2 gap-3">

        <button
          onClick={onRotateLeft}
          className="flex items-center justify-center gap-2 rounded-xl border px-4 py-3 transition hover:bg-muted"
        >
          <RotateCcw className="h-5 w-5" />
          Left 90°
        </button>

        <button
          onClick={onRotateRight}
          className="flex items-center justify-center gap-2 rounded-xl border px-4 py-3 transition hover:bg-muted"
        >
          <RotateCw className="h-5 w-5" />
          Right 90°
        </button>

      </div>

      {/* Rotate 180 */}

      <button
        onClick={onRotate180}
        className="mt-4 w-full rounded-xl border px-4 py-3 transition hover:bg-muted"
      >
        Rotate 180°
      </button>

      {/* Reset */}

      <button
        onClick={onReset}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 font-semibold text-primary-foreground transition hover:opacity-90"
      >
        <RefreshCw className="h-4 w-4" />
        Reset Rotation
      </button>

    </div>
  );
}