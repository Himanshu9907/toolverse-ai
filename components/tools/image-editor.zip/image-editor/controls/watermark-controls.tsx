"use client";

interface Props {
  editor: any;
}

export function WatermarkControls({
  editor,
}: Props) {
  return (
    <div className="rounded-2xl border bg-card p-6">

      <h3 className="text-lg font-bold">
        Watermark
      </h3>

      <p className="mt-2 text-sm text-muted-foreground">
        Watermark panel coming next.
      </p>

    </div>
  );
}