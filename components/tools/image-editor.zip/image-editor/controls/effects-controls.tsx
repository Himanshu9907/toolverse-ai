"use client";

interface Props {
  editor: any;
}

export function EffectsControls({
  editor,
}: Props) {
  return (
    <div className="rounded-2xl border bg-card p-6">

      <h3 className="text-lg font-bold">
        Effects
      </h3>

      <p className="mt-2 text-sm text-muted-foreground">
        Effects panel coming next.
      </p>

    </div>
  );
}