// "use client";

// import {
//   Crop,
//   MoveHorizontal,
//   RotateCw,
//   FlipHorizontal,
//   FlipVertical,
// } from "lucide-react";

// export function TransformControls() {
//   return (
//     <div className="rounded-2xl border bg-card p-6 shadow-sm">

//       <h3 className="mb-6 text-lg font-bold">
//         Transform
//       </h3>

//       {/* Crop */}

//       <button className="mb-3 flex w-full items-center justify-between rounded-xl border p-4 transition hover:bg-muted">

//         <div className="flex items-center gap-3">

//           <Crop className="h-5 w-5 text-primary" />

//           <span className="font-medium">
//             Crop Image
//           </span>

//         </div>

//       </button>

//       {/* Resize */}

//       <button className="mb-3 flex w-full items-center justify-between rounded-xl border p-4 transition hover:bg-muted">

//         <div className="flex items-center gap-3">

//           <MoveHorizontal className="h-5 w-5 text-primary" />

//           <span className="font-medium">
//             Resize Image
//           </span>

//         </div>

//       </button>

//       {/* Rotate */}

//       <button className="mb-3 flex w-full items-center justify-between rounded-xl border p-4 transition hover:bg-muted">

//         <div className="flex items-center gap-3">

//           <RotateCw className="h-5 w-5 text-primary" />

//           <span className="font-medium">
//             Rotate
//           </span>

//         </div>

//       </button>

//       {/* Flip Horizontal */}

//       <button className="mb-3 flex w-full items-center justify-between rounded-xl border p-4 transition hover:bg-muted">

//         <div className="flex items-center gap-3">

//           <FlipHorizontal className="h-5 w-5 text-primary" />

//           <span className="font-medium">
//             Flip Horizontal
//           </span>

//         </div>

//       </button>

//       {/* Flip Vertical */}

//       <button className="flex w-full items-center justify-between rounded-xl border p-4 transition hover:bg-muted">

//         <div className="flex items-center gap-3">

//           <FlipVertical className="h-5 w-5 text-primary" />

//           <span className="font-medium">
//             Flip Vertical
//           </span>

//         </div>

//       </button>

//     </div>
//   );
// }


// "use client";

// import { useState } from "react";

// import { CropPanel } from "../panels/crop-panel";
// import { ResizePanel } from "../panels/resize-panel";
// import { RotatePanel } from "../panels/rotate-panel";
// import { FlipPanel } from "../panels/flip-panel";

// type TransformTool =
//   | "crop"
//   | "resize"
//   | "rotate"
//   | "flip";

// export function TransformControls() {
//   const [activeTool, setActiveTool] =
//     useState<TransformTool>("crop");

//   /* Crop */

//   const [aspectRatio, setAspectRatio] =
//     useState("free");

//   /* Resize */

//   const [width, setWidth] =
//     useState(1920);

//   const [height, setHeight] =
//     useState(1080);

//   const [keepAspectRatio, setKeepAspectRatio] =
//     useState(true);

//   /* Rotate */

//   const [rotation, setRotation] =
//     useState(0);

//   /* Flip */

//   const [flipH, setFlipH] =
//     useState(false);

//   const [flipV, setFlipV] =
//     useState(false);

//   return (
//     <div className="space-y-6">

//       {/* Tool Switcher */}

//       <div className="grid grid-cols-2 gap-3">

//         <button
//           onClick={() =>
//             setActiveTool("crop")
//           }
//           className={`rounded-xl border px-4 py-3 font-medium transition

//           ${
//             activeTool === "crop"
//               ? "bg-primary text-primary-foreground"
//               : "hover:bg-muted"
//           }`}
//         >
//           Crop
//         </button>

//         <button
//           onClick={() =>
//             setActiveTool("resize")
//           }
//           className={`rounded-xl border px-4 py-3 font-medium transition

//           ${
//             activeTool === "resize"
//               ? "bg-primary text-primary-foreground"
//               : "hover:bg-muted"
//           }`}
//         >
//           Resize
//         </button>

//         <button
//           onClick={() =>
//             setActiveTool("rotate")
//           }
//           className={`rounded-xl border px-4 py-3 font-medium transition

//           ${
//             activeTool === "rotate"
//               ? "bg-primary text-primary-foreground"
//               : "hover:bg-muted"
//           }`}
//         >
//           Rotate
//         </button>

//         <button
//           onClick={() =>
//             setActiveTool("flip")
//           }
//           className={`rounded-xl border px-4 py-3 font-medium transition

//           ${
//             activeTool === "flip"
//               ? "bg-primary text-primary-foreground"
//               : "hover:bg-muted"
//           }`}
//         >
//           Flip
//         </button>

//       </div>

//       {/* Crop */}

//       {activeTool === "crop" && (
//         <CropPanel
//           aspectRatio={aspectRatio}
//           onAspectRatioChange={
//             setAspectRatio
//           }
//           onApplyCrop={() =>
//             console.log("Crop")
//           }
//         />
//       )}

//       {/* Resize */}

//       {activeTool === "resize" && (
//         <ResizePanel
//           width={width}
//           height={height}
//           keepAspectRatio={
//             keepAspectRatio
//           }
//           onWidthChange={setWidth}
//           onHeightChange={setHeight}
//           onToggleAspectRatio={() =>
//             setKeepAspectRatio(
//               !keepAspectRatio
//             )
//           }
//           onResize={() =>
//             console.log("Resize")
//           }
//         />
//       )}

//       {/* Rotate */}

//       {activeTool === "rotate" && (
//         <RotatePanel
//           rotation={rotation}
//           onRotateLeft={() =>
//             setRotation(
//               (prev) => prev - 90
//             )
//           }
//           onRotateRight={() =>
//             setRotation(
//               (prev) => prev + 90
//             )
//           }
//           onRotate180={() =>
//             setRotation(
//               (prev) => prev + 180
//             )
//           }
//           onReset={() =>
//             setRotation(0)
//           }
//         />
//       )}

//       {/* Flip */}

//       {activeTool === "flip" && (
//         <FlipPanel
//           isFlippedHorizontal={
//             flipH
//           }
//           isFlippedVertical={
//             flipV
//           }
//           onFlipHorizontal={() =>
//             setFlipH(!flipH)
//           }
//           onFlipVertical={() =>
//             setFlipV(!flipV)
//           }
//           onReset={() => {
//             setFlipH(false);
//             setFlipV(false);
//           }}
//         />
//       )}

//     </div>
//   );
// }


"use client";

import { useState } from "react";

import { CropPanel } from "../panels/crop-panel";
import { ResizePanel } from "../panels/resize-panel";
import { RotatePanel } from "../panels/rotate-panel";
import { FlipPanel } from "../panels/flip-panel";

interface Props {
  editor: any;
}

type Tool =
  | "crop"
  | "resize"
  | "rotate"
  | "flip";

export function TransformControls({
  editor,
}: Props) {

  const [tool, setTool] =
    useState<Tool>("crop");

  return (
    <div className="space-y-5">

      <div className="grid grid-cols-2 gap-3">

        <button
          onClick={() => setTool("crop")}
          className={tool === "crop"
            ? "rounded-xl bg-primary px-4 py-3 text-primary-foreground"
            : "rounded-xl border px-4 py-3"}
        >
          Crop
        </button>

        <button
          onClick={() => setTool("resize")}
          className={tool === "resize"
            ? "rounded-xl bg-primary px-4 py-3 text-primary-foreground"
            : "rounded-xl border px-4 py-3"}
        >
          Resize
        </button>

        <button
          onClick={() => setTool("rotate")}
          className={tool === "rotate"
            ? "rounded-xl bg-primary px-4 py-3 text-primary-foreground"
            : "rounded-xl border px-4 py-3"}
        >
          Rotate
        </button>

        <button
          onClick={() => setTool("flip")}
          className={tool === "flip"
            ? "rounded-xl bg-primary px-4 py-3 text-primary-foreground"
            : "rounded-xl border px-4 py-3"}
        >
          Flip
        </button>

      </div>

      {tool === "crop" && (
        <CropPanel
          aspectRatio={editor.cropAspectRatio}
          onAspectRatioChange={
            editor.setCropAspectRatio
          }
          onApplyCrop={editor.applyChanges}
        />
      )}

      {tool === "resize" && (
        <ResizePanel
          width={editor.resizeWidth}
          height={editor.resizeHeight}
          keepAspectRatio={editor.keepAspectRatio}
          onWidthChange={editor.setResizeWidth}
          onHeightChange={editor.setResizeHeight}
          onToggleAspectRatio={() =>
            editor.setKeepAspectRatio(
              !editor.keepAspectRatio
            )
          }
          onResize={() =>
            editor.applyResize(
              editor.resizeWidth,
              editor.resizeHeight
            )
          }
        />
      )}

      {tool === "rotate" && (
        <RotatePanel
          rotation={editor.rotation}
          onRotateLeft={editor.rotateLeft}
          onRotateRight={editor.rotateRight}
          onRotate180={editor.rotate180}
          onReset={editor.resetTransform}
        />
      )}

      {tool === "flip" && (
        <FlipPanel
          isFlippedHorizontal={
            editor.flipHorizontal
          }
          isFlippedVertical={
            editor.flipVertical
          }
          onFlipHorizontal={
            editor.toggleFlipHorizontal
          }
          onFlipVertical={
            editor.toggleFlipVertical
          }
          onReset={editor.resetTransform}
        />
      )}

    </div>
  );
}