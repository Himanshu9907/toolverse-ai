"use client";

interface Props {
  editor: any;
}

export function MetadataPanel({
  editor,
}: Props) {
  return (
    <div className="rounded-2xl border bg-card p-6">

      <h3 className="text-lg font-bold">
        Metadata
      </h3>

      <div className="mt-5 space-y-3">

        <div className="flex justify-between">

          <span>Width</span>

          <span>
            {editor.imageState.width}px
          </span>

        </div>

        <div className="flex justify-between">

          <span>Height</span>

          <span>
            {editor.imageState.height}px
          </span>

        </div>

        <div className="flex justify-between">

          <span>Size</span>

          <span>
            {editor.imageState.fileSize}
          </span>

        </div>

      </div>

    </div>
  );
}