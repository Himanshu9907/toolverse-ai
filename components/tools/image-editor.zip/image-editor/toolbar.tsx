"use client";

import {
  Crop,
  Move,
  Palette,
  Droplets,
  Info,
} from "lucide-react";

export type EditorTab =
  | "transform"
  | "effects"
  | "watermark"
  | "metadata";

interface ToolbarProps {
  activeTab: EditorTab;
  onTabChange: (tab: EditorTab) => void;
}

const tabs = [
  {
    id: "transform" as EditorTab,
    label: "Transform",
    icon: Move,
  },
  {
    id: "effects" as EditorTab,
    label: "Effects",
    icon: Palette,
  },
  {
    id: "watermark" as EditorTab,
    label: "Watermark",
    icon: Droplets,
  },
  {
    id: "metadata" as EditorTab,
    label: "Metadata",
    icon: Info,
  },
];

export function Toolbar({
  activeTab,
  onTabChange,
}: ToolbarProps) {
  return (
    <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">

      <div className="flex flex-wrap gap-2 p-3">

        {tabs.map((tab) => {
          const Icon = tab.icon;

          const active = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium transition-all duration-200

              ${
                active
                  ? "bg-primary text-primary-foreground shadow"
                  : "hover:bg-muted"
              }`}
            >
              <Icon className="h-4 w-4" />

              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

    </div>
  );
}