// "use client";

// import {
//   useRef,
//   useState,
//   useCallback,
// } from "react";

// export interface ImageState {
//   file: File | null;

//   image: HTMLImageElement | null;

//   preview: string;

//   width: number;

//   height: number;

//   fileSize: string;
// }

// export function useImageEditor() {

//     /* -----------------------------
//    Active Tab
// ------------------------------ */

// const [activeTab, setActiveTab] =
//   useState<
//     "transform" |
//     "effects" |
//     "watermark" |
//     "metadata"
//   >("transform");

//   /* -----------------------------
//      Canvas
//   ------------------------------ */

//   const canvasRef =
//     useRef<HTMLCanvasElement>(null);

//   const imageRef =
//     useRef<HTMLImageElement | null>(null);

//   /* -----------------------------
//      Image State
//   ------------------------------ */

//   const [imageState, setImageState] =
//     useState<ImageState>({
//       file: null,
//       image: null,
//       preview: "",
//       width: 0,
//       height: 0,
//       fileSize: "",
//     });

//   /* -----------------------------
//      Transform State
//   ------------------------------ */

//   const [rotation, setRotation] =
//     useState(0);

//   const [flipHorizontal, setFlipHorizontal] =
//     useState(false);

//   const [flipVertical, setFlipVertical] =
//     useState(false);

//   const [cropAspectRatio, setCropAspectRatio] =
//     useState("free");

//     /* -----------------------------
//    Crop State
// ------------------------------ */

// const [crop, setCrop] = useState({
//   x: 0,
//   y: 0,
// });

// const [zoom, setZoom] =
//   useState(1);

// const [
//   croppedAreaPixels,
//   setCroppedAreaPixels,
// ] = useState<any>(null);

// const onCropComplete = (
//   _: any,
//   croppedPixels: any
// ) => {
//   setCroppedAreaPixels(
//     croppedPixels
//   );
// };

//   /* -----------------------------
//      Resize
//   ------------------------------ */

//   const [resizeWidth, setResizeWidth] =
//     useState(0);

//   const [resizeHeight, setResizeHeight] =
//     useState(0);

//   const [keepAspectRatio, setKeepAspectRatio] =
//     useState(true);

//   /* -----------------------------
//      Filters
//   ------------------------------ */

//   const [brightness, setBrightness] =
//     useState(100);

//   const [contrast, setContrast] =
//     useState(100);

//   const [saturation, setSaturation] =
//     useState(100);

//   const [blur, setBlur] =
//     useState(0);

//   const [grayscale, setGrayscale] =
//     useState(false);

//   const [sepia, setSepia] =
//     useState(false);

//   const [invert, setInvert] =
//     useState(false);

//   /* -----------------------------
//      Loading
//   ------------------------------ */

//   const [loading, setLoading] =
//     useState(false);

//   /* -----------------------------
//      Upload Image
//   ------------------------------ */

//   const loadImage = useCallback(
//     (file: File) => {

//       const url =
//         URL.createObjectURL(file);

//       const img =
//         new Image();

//       img.src = url;

//       img.onload = () => {

//         imageRef.current = img;

//         setImageState({

//           file,

//           image: img,

//           preview: url,

//           width: img.width,

//           height: img.height,

//           fileSize:
//             (
//               file.size /
//               1024 /
//               1024
//             ).toFixed(2) + " MB",

//         });

//         setResizeWidth(img.width);

//         setResizeHeight(img.height);

//       };

//     },
//     []
//   );
//     /* -----------------------------
//      Draw Canvas
//   ------------------------------ */

//   const drawCanvas = useCallback(() => {

//     if (
//       !canvasRef.current ||
//       !imageRef.current
//     )
//       return;

//     const canvas = canvasRef.current;

//     const ctx =
//       canvas.getContext("2d");

//     if (!ctx) return;

//     canvas.width = resizeWidth;

//     canvas.height = resizeHeight;

//     ctx.clearRect(
//       0,
//       0,
//       canvas.width,
//       canvas.height
//     );

//     ctx.save();

//     ctx.translate(
//       canvas.width / 2,
//       canvas.height / 2
//     );

//     ctx.rotate(
//       (rotation * Math.PI) / 180
//     );

//     ctx.scale(
//       flipHorizontal ? -1 : 1,
//       flipVertical ? -1 : 1
//     );

//     ctx.filter = `
//       brightness(${brightness}%)
//       contrast(${contrast}%)
//       saturate(${saturation}%)
//       blur(${blur}px)
//       grayscale(${grayscale ? 100 : 0}%)
//       sepia(${sepia ? 100 : 0}%)
//       invert(${invert ? 100 : 0}%)
//     `;

//     ctx.drawImage(
//       imageRef.current,
//       -resizeWidth / 2,
//       -resizeHeight / 2,
//       resizeWidth,
//       resizeHeight
//     );

//     ctx.restore();

//   }, [
//     rotation,
//     flipHorizontal,
//     flipVertical,
//     resizeWidth,
//     resizeHeight,
//     brightness,
//     contrast,
//     saturation,
//     blur,
//     grayscale,
//     sepia,
//     invert,
//   ],

// );

//   /* -----------------------------
//      Rotate
//   ------------------------------ */

//   const rotateLeft = () =>
//     setRotation((prev) => prev - 90);

//   const rotateRight = () =>
//     setRotation((prev) => prev + 90);

//   const rotate180 = () =>
//     setRotation((prev) => prev + 180);

//   /* -----------------------------
//      Flip
//   ------------------------------ */

//   const toggleFlipHorizontal =
//     () =>
//       setFlipHorizontal(
//         (prev) => !prev
//       );

//   const toggleFlipVertical =
//     () =>
//       setFlipVertical(
//         (prev) => !prev
//       );

//   /* -----------------------------
//      Resize
//   ------------------------------ */

//   const applyResize = (
//     width: number,
//     height: number
//   ) => {

//     setResizeWidth(width);

//     setResizeHeight(height);

//   };

//   /* -----------------------------
//      Reset Transform
//   ------------------------------ */

//   const resetTransform =
//     () => {

//       if (!imageRef.current)
//         return;

//       setRotation(0);

//       setFlipHorizontal(false);

//       setFlipVertical(false);

//       setResizeWidth(
//         imageRef.current.width
//       );

//       setResizeHeight(
//         imageRef.current.height
//       );

//     };
//       /* -----------------------------
//      Reset Filters
//   ------------------------------ */

//   const resetFilters = () => {

//     setBrightness(100);

//     setContrast(100);

//     setSaturation(100);

//     setBlur(0);

//     setGrayscale(false);

//     setSepia(false);

//     setInvert(false);

//   };

//   /* -----------------------------
//      Reset All
//   ------------------------------ */

//   const resetAll = () => {

//     resetTransform();

//     resetFilters();

//   };

//   /* -----------------------------
//      Download
//   ------------------------------ */

//   const downloadImage = (
//     filename = "toolverse-image.png"
//   ) => {

//     if (!canvasRef.current)
//       return;

//     const link =
//       document.createElement("a");

//     link.download = filename;

//     link.href =
//       canvasRef.current.toDataURL(
//         "image/png"
//       );

//     link.click();

//   };

//   /* -----------------------------
//      Apply Changes
//   ------------------------------ */

//   const applyChanges =
//     useCallback(() => {

//       drawCanvas();

//     }, [drawCanvas]);

//   /* -----------------------------
//      Return
//   ------------------------------ */

//   return {

//     /* refs */

//     canvasRef,

//     imageRef,

//     /* state */

//     imageState,

//     loading,

//     /* upload */

//     loadImage,

//     /* transform */

//     rotation,

//     rotateLeft,

//     rotateRight,

//     rotate180,

//     flipHorizontal,

//     flipVertical,

//     toggleFlipHorizontal,

//     toggleFlipVertical,

//     cropAspectRatio,

//     setCropAspectRatio,

//     resizeWidth,

//     resizeHeight,

//     setResizeWidth,

//     setResizeHeight,

//     keepAspectRatio,

//     setKeepAspectRatio,

//     applyResize,

//     resetTransform,

//     /* filters */

//     brightness,

//     setBrightness,

//     contrast,

//     setContrast,

//     saturation,

//     setSaturation,

//     blur,

//     setBlur,

//     grayscale,

//     setGrayscale,

//     sepia,

//     setSepia,

//     invert,

//     setInvert,

//     resetFilters,

//     /* canvas */

//     drawCanvas,

//     applyChanges,

//     /* download */

//     downloadImage,

//     /* reset */

//     resetAll,

//     /* navigation */

//     activeTab,

//     setActiveTab,

//     crop,
// setCrop,

// zoom,
// setZoom,

// croppedAreaPixels,

// onCropComplete,

//   };

// }


// "use client";

// import { useCallback, useRef, useState } from "react";

// import ImageEngine from "../engine/image-engine";

// import type {
//   CropArea,
//   FilterOptions,
//   ImageEngineOptions,
//   ResizeOptions,
//   RotationOptions,
//   WatermarkOptions,
// } from "../engine/types";

// export interface ImageEditorState {
//   file: File | null;
//   preview: string;
//   width: number;
//   height: number;
//   fileSize: string;
// }

// export function useImageEditor() {

//   const engineRef =
//     useRef<ImageEngine | null>(null);

//   const canvasRef =
//     useRef<HTMLCanvasElement>(null);

//   const [loading, setLoading] =
//     useState(false);

//   const [editorState, setEditorState] =
//     useState<ImageEditorState>({
//       file: null,
//       preview: "",
//       width: 0,
//       height: 0,
//       fileSize: "",
//     });

//   const [filters, setFilters] =
//     useState<FilterOptions>({
//       brightness: 100,
//       contrast: 100,
//       saturation: 100,
//       blur: 0,
//       grayscale: false,
//       sepia: false,
//       invert: false,
//     });

//   const [transform, setTransform] =
//     useState<RotationOptions>({
//       rotation: 0,
//       flipHorizontal: false,
//       flipVertical: false,
//     });

//  const [resize, setResize] =
//   useState<ResizeOptions>({
//     width: 0,
//     height: 0,
//     keepAspectRatio: true,
//   });

//   const [crop, setCrop] =
//     useState<CropArea | null>(null);

//     const [cropAspectRatio, setCropAspectRatio] =
//   useState("free");

//   const [watermark, setWatermark] =
//     useState<WatermarkOptions>({
//       enabled: false,
//       text: "",
//       opacity: 0.5,
//       fontSize: 32,
//       color: "#ffffff",
//       x: 20,
//       y: 20,
//     });

//     const [activeTab, setActiveTab] = useState<
//   "transform" | "effects" | "watermark" | "metadata"
// >("transform");

//   const loadImage =
//     useCallback(
//       async (file: File) => {

//         setLoading(true);

//         try {

//           const preview =
//             URL.createObjectURL(file);

//           const engine =
//             new ImageEngine();

//           await engine.load(preview);

//           engineRef.current =
//             engine;

//           setEditorState({
//             file,
//             preview,
//             width:
//               engine.getWidth(),
//             height:
//               engine.getHeight(),
//             fileSize:
//               (
//                 file.size /
//                 1024 /
//                 1024
//               ).toFixed(2) + " MB",
//           });

//          setResize({
//   width: engine.getWidth(),
//   height: engine.getHeight(),
//   keepAspectRatio: true,
// });

//         } finally {

//           setLoading(false);

//         }

//       },
//       []
//     );

//       /* --------------------------------
//      Render Engine
//   -------------------------------- */

//   const render =
//     useCallback(async () => {

//       if (!engineRef.current)
//         return;

//       setLoading(true);

//       try {

//         const options: ImageEngineOptions = {

//           crop: crop ?? undefined,

//           resize,

//           transform,

//           filters,

//           watermark,

//         };

//         await engineRef.current.apply(
//           options
//         );

//         if (canvasRef.current) {

//           const ctx =
//             canvasRef.current.getContext(
//               "2d"
//             );

//           if (ctx) {

//             const canvas =
//               engineRef.current.getCanvas();

//             canvasRef.current.width =
//               canvas.width;

//             canvasRef.current.height =
//               canvas.height;

//             ctx.clearRect(
//               0,
//               0,
//               canvas.width,
//               canvas.height
//             );

//             ctx.drawImage(
//               canvas,
//               0,
//               0
//             );

//           }

//         }

//       } finally {

//         setLoading(false);

//       }

//     }, [
//       crop,
//       resize,
//       transform,
//       filters,
//       watermark,
//     ]);

//   /* --------------------------------
//      Apply Changes
//   -------------------------------- */

//   const applyChanges =
//     useCallback(async () => {

//       await render();

//     }, [render]);

//   /* --------------------------------
//      Rotate
//   -------------------------------- */

//   const rotateLeft = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation:
//         prev.rotation - 90,
//     }));

//   };

//   const rotateRight = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation:
//         prev.rotation + 90,
//     }));

//   };

//   const rotate180 = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation:
//         prev.rotation + 180,
//     }));

//   };

//   /* --------------------------------
//      Flip
//   -------------------------------- */

//   const toggleFlipHorizontal =
//     () => {

//       setTransform(prev => ({
//         ...prev,
//         flipHorizontal:
//           !prev.flipHorizontal,
//       }));

//     };

//   const toggleFlipVertical =
//     () => {

//       setTransform(prev => ({
//         ...prev,
//         flipVertical:
//           !prev.flipVertical,
//       }));

//     };

//   /* --------------------------------
//      Resize
//   -------------------------------- */

//   const applyResize = (
//     width: number,
//     height: number
//   ) => {

//    setResize(prev => ({
//   ...prev,
//   width,
//   height,
// }));
//   };

//   /* --------------------------------
//      Crop
//   -------------------------------- */

//   const applyCrop = (
//     area: CropArea
//   ) => {

//     setCrop(area);

//   };
//     /* --------------------------------
//      Download
//   -------------------------------- */

//   const downloadImage =
//     useCallback(async () => {

//       if (!engineRef.current)
//         return;

//       await engineRef.current.download();

//     }, []);

//   /* --------------------------------
//      Reset Transform
//   -------------------------------- */

//   const resetTransform =
//     () => {

//       setTransform({
//         rotation: 0,
//         flipHorizontal: false,
//         flipVertical: false,
//       });

//       setCrop(null);

//       if (
//         engineRef.current
//       ) {

//         setResize({
//   width: engineRef.current.getWidth(),
//   height: engineRef.current.getHeight(),
//   keepAspectRatio: true,
// });

//       }

//     };

//   /* --------------------------------
//      Reset Filters
//   -------------------------------- */

//   const resetFilters =
//     () => {

//       setFilters({
//         brightness: 100,
//         contrast: 100,
//         saturation: 100,
//         blur: 0,
//         grayscale: false,
//         sepia: false,
//         invert: false,
//       });

//     };

//   /* --------------------------------
//      Reset All
//   -------------------------------- */

//   const resetAll =
//     () => {

//       resetTransform();

//       resetFilters();

//       setWatermark({
//         enabled: false,
//         text: "",
//         opacity: 0.5,
//         fontSize: 32,
//         color: "#ffffff",
//         x: 20,
//         y: 20,
//       });

//     };

//   /* --------------------------------
//      Return
//   -------------------------------- */

//   return {

    

//     /* refs */

//     canvasRef,

//     engineRef,

//     /* state */

//     loading,

//     editorState,

//     filters,

//     transform,

//     resize,

//     crop,

//     watermark,

//       /* Compatibility */

//   rotation: transform.rotation,
//   flipHorizontal: transform.flipHorizontal,
//   flipVertical: transform.flipVertical,

//   cropAspectRatio: crop.aspectRatio,

//   setCropAspectRatio: (value: string) =>
//     setCrop(prev => ({
//       ...prev,
//       aspectRatio: value,
//     })),

//   resizeWidth: resize.width,
//   resizeHeight: resize.height,

//   setResizeWidth: (width: number) =>
//     setResize(prev => ({
//       ...prev,
//       width,
//     })),

//   setResizeHeight: (height: number) =>
//     setResize(prev => ({
//       ...prev,
//       height,
//     })),

//   keepAspectRatio: resize.keepAspectRatio,

//   setKeepAspectRatio: (value: boolean) =>
//     setResize(prev => ({
//       ...prev,
//       keepAspectRatio: value,
//     })),



//     /* setters */

//     setFilters,

//     setTransform,

//     setResize,

//     setCrop,

//     setWatermark,

//     /* upload */

//     loadImage,

//     /* actions */

//     applyChanges,

//     applyResize,

//     applyCrop,

//     rotateLeft,

//     rotateRight,

//     rotate180,

//     toggleFlipHorizontal,

//     toggleFlipVertical,

//     downloadImage,

//     resetTransform,

//     resetFilters,

//     resetAll,

//     imageState: editorState,

//     activeTab,
// setActiveTab,

//   };

// }

// "use client";

// import { useCallback, useRef, useState } from "react";

// import ImageEngine from "../engine/image-engine";

// import type {
//   CropArea,
//   FilterOptions,
//   ImageEngineOptions,
//   ResizeOptions,
//   RotationOptions,
//   WatermarkOptions,
// } from "../engine/types";

// export interface ImageEditorState {
//   file: File | null;
//   preview: string;
//   width: number;
//   height: number;
//   fileSize: string;
// }

// export function useImageEditor() {

//   /* --------------------------------
//       Refs
//   -------------------------------- */

//   const engineRef =
//     useRef<ImageEngine | null>(null);

//   const canvasRef =
//     useRef<HTMLCanvasElement>(null);

//   /* --------------------------------
//       Loading
//   -------------------------------- */

//   const [loading, setLoading] =
//     useState(false);

//   /* --------------------------------
//       Active Tab
//   -------------------------------- */

//   const [activeTab, setActiveTab] =
//     useState<
//       "transform" |
//       "effects" |
//       "watermark" |
//       "metadata"
//     >("transform");

//   /* --------------------------------
//       Image State
//   -------------------------------- */

//   const [imageState, setImageState] =
//     useState<ImageEditorState>({
//       file: null,
//       preview: "",
//       width: 0,
//       height: 0,
//       fileSize: "",
//     });

//   /* --------------------------------
//       Filters
//   -------------------------------- */

//   const [filters, setFilters] =
//     useState<FilterOptions>({
//       brightness: 100,
//       contrast: 100,
//       saturation: 100,
//       blur: 0,
//       grayscale: false,
//       sepia: false,
//       invert: false,
//     });

//   /* --------------------------------
//       Transform
//   -------------------------------- */

//   const [transform, setTransform] =
//     useState<RotationOptions>({
//       rotation: 0,
//       flipHorizontal: false,
//       flipVertical: false,
//     });

//   /* --------------------------------
//       Resize
//   -------------------------------- */

//   const [resize, setResize] =
//     useState<ResizeOptions>({
//       width: 0,
//       height: 0,
//       keepAspectRatio: true,
//     });

//   /* --------------------------------
//       Crop
//   -------------------------------- */

//   const [crop, setCrop] =
//     useState<CropArea | null>(null);

//   const [cropAspectRatio,
//     setCropAspectRatio] =
//     useState("free");

//   /* --------------------------------
//       Watermark
//   -------------------------------- */

//   const [watermark,
//     setWatermark] =
//     useState<WatermarkOptions>({
//       enabled: false,
//       text: "",
//       opacity: 0.5,
//       fontSize: 32,
//       color: "#ffffff",
//       x: 20,
//       y: 20,
//     });
//       /* --------------------------------
//       Load Image
//   -------------------------------- */

//   const loadImage = useCallback(
//     async (file: File) => {

//       setLoading(true);

//       try {

//         const preview =
//           URL.createObjectURL(file);

//         const engine =
//           new ImageEngine();

//         await engine.load(preview);

//         engineRef.current =
//           engine;

//         setImageState({

//           file,

//           preview,

//           width:
//             engine.getWidth(),

//           height:
//             engine.getHeight(),

//           fileSize:
//             (
//               file.size /
//               1024 /
//               1024
//             ).toFixed(2) + " MB",

//         });

//         setResize({

//           width:
//             engine.getWidth(),

//           height:
//             engine.getHeight(),

//           keepAspectRatio: true,

//         });

//       } finally {

//         setLoading(false);

//       }

//     },
//     []
//   );

//   /* --------------------------------
//       Render Canvas
//   -------------------------------- */

//   const renderCanvas =
//     useCallback(async () => {

//       if (
//         !engineRef.current ||
//         !canvasRef.current
//       ) return;

//       const options: ImageEngineOptions = {

//         crop: crop ?? undefined,

//         resize,

//         transform,

//         filters,

//         watermark,

//       };

//       await engineRef.current.apply(
//         options
//       );

//       const canvas =
//         engineRef.current.getCanvas();

//       const ctx =
//         canvasRef.current.getContext("2d");

//       if (!ctx) return;

//       canvasRef.current.width =
//         canvas.width;

//       canvasRef.current.height =
//         canvas.height;

//       ctx.clearRect(
//         0,
//         0,
//         canvas.width,
//         canvas.height
//       );

//       ctx.drawImage(
//         canvas,
//         0,
//         0
//       );

//     }, [
//       crop,
//       resize,
//       transform,
//       filters,
//       watermark,
//     ]);

//   /* --------------------------------
//       Apply Changes
//   -------------------------------- */

//   const applyChanges =
//     useCallback(async () => {

//       await renderCanvas();

//     }, [
//       renderCanvas,
//     ]);

//       /* --------------------------------
//       Rotate
//   -------------------------------- */

//   const rotateLeft = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation: prev.rotation - 90,
//     }));

//   };

//   const rotateRight = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation: prev.rotation + 90,
//     }));

//   };

//   const rotate180 = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation: prev.rotation + 180,
//     }));

//   };

//   /* --------------------------------
//       Flip
//   -------------------------------- */

//   const toggleFlipHorizontal = () => {

//     setTransform(prev => ({
//       ...prev,
//       flipHorizontal: !prev.flipHorizontal,
//     }));

//   };

//   const toggleFlipVertical = () => {

//     setTransform(prev => ({
//       ...prev,
//       flipVertical: !prev.flipVertical,
//     }));

//   };

//   /* --------------------------------
//       Resize
//   -------------------------------- */

//   const applyResize = (
//     width: number,
//     height: number
//   ) => {

//     setResize(prev => ({
//       ...prev,
//       width,
//       height,
//     }));

//   };

//   /* --------------------------------
//       Crop
//   -------------------------------- */

//   const applyCrop = (
//     area: CropArea
//   ) => {

//     setCrop(area);

//   };

//   /* --------------------------------
//       Download
//   -------------------------------- */

//   const downloadImage =
//     useCallback(async () => {

//       if (!engineRef.current)
//         return;

//       await engineRef.current.download();

//     }, []);

//   /* --------------------------------
//       Reset Transform
//   -------------------------------- */

//   const resetTransform = () => {

//     setTransform({
//       rotation: 0,
//       flipHorizontal: false,
//       flipVertical: false,
//     });

//     setCrop(null);

//     if (engineRef.current) {

//       setResize({
//         width: engineRef.current.getWidth(),
//         height: engineRef.current.getHeight(),
//         keepAspectRatio: true,
//       });

//     }

//   };

//   /* --------------------------------
//       Reset Filters
//   -------------------------------- */

//   const resetFilters = () => {

//     setFilters({
//       brightness: 100,
//       contrast: 100,
//       saturation: 100,
//       blur: 0,
//       grayscale: false,
//       sepia: false,
//       invert: false,
//     });

//   };

//   /* --------------------------------
//       Reset All
//   -------------------------------- */

//   const resetAll = () => {

//     resetTransform();

//     resetFilters();

//     setWatermark({
//       enabled: false,
//       text: "",
//       opacity: 0.5,
//       fontSize: 32,
//       color: "#ffffff",
//       x: 20,
//       y: 20,
//     });

//   };
//     /* --------------------------------
//       Compatibility
//   -------------------------------- */

//   const rotation =
//     transform.rotation;

//   const flipHorizontal =
//     transform.flipHorizontal;

//   const flipVertical =
//     transform.flipVertical;

//   const resizeWidth =
//     resize.width;

//   const resizeHeight =
//     resize.height;

//   const keepAspectRatio =
//     resize.keepAspectRatio;

//   const setResizeWidth = (
//     width: number
//   ) => {

//     setResize(prev => ({
//       ...prev,
//       width,
//     }));

//   };

//   const setResizeHeight = (
//     height: number
//   ) => {

//     setResize(prev => ({
//       ...prev,
//       height,
//     }));

//   };

//   const setKeepAspectRatio = (
//     value: boolean
//   ) => {

//     setResize(prev => ({
//       ...prev,
//       keepAspectRatio: value,
//     }));

//   };

//   /* --------------------------------
//       Return
//   -------------------------------- */

//   return {

//     /* refs */

//     canvasRef,

//     engineRef,

//     /* state */

//     loading,

//     imageState,

//     filters,

//     transform,

//     resize,

//     crop,

//     watermark,

//     activeTab,

//     setActiveTab,

//     /* upload */

//     loadImage,

//     /* render */

//     applyChanges,

//     /* transform */

//     rotation,

//     rotateLeft,

//     rotateRight,

//     rotate180,

//     flipHorizontal,

//     flipVertical,

//     toggleFlipHorizontal,

//     toggleFlipVertical,

//     cropAspectRatio,

//     setCropAspectRatio,

//     resizeWidth,

//     resizeHeight,

//     setResizeWidth,

//     setResizeHeight,

//     keepAspectRatio,

//     setKeepAspectRatio,

//     applyResize,

//     applyCrop,

//     resetTransform,

//     /* filters */

//     setFilters,

//     resetFilters,

//     /* watermark */

//     setWatermark,

//     /* download */

//     downloadImage,

//     /* reset */

//     resetAll,

//   };

// }

// "use client";

// import { useCallback, useRef, useState } from "react";

// import ImageEngine from "../engine/image-engine";

// import type {
//   CropArea,
//   FilterOptions,
//   ImageEngineOptions,
//   ResizeOptions,
//   RotationOptions,
//   WatermarkOptions,
// } from "../engine/types";

// export interface ImageEditorState {
//   file: File | null;
//   preview: string;
//   width: number;
//   height: number;
//   fileSize: string;
// }

// export function useImageEditor() {

//   const engineRef =
//     useRef<ImageEngine | null>(null);

//   const canvasRef =
//     useRef<HTMLCanvasElement>(null);

//   const [loading, setLoading] =
//     useState(false);

//   const [editorState, setEditorState] =
//     useState<ImageEditorState>({
//       file: null,
//       preview: "",
//       width: 0,
//       height: 0,
//       fileSize: "",
//     });

//   const [activeTab, setActiveTab] =
//     useState<
//       "transform" |
//       "effects" |
//       "watermark" |
//       "metadata"
//     >("transform");

//   const [filters, setFilters] =
//     useState<FilterOptions>({
//       brightness: 100,
//       contrast: 100,
//       saturation: 100,
//       blur: 0,
//       grayscale: false,
//       sepia: false,
//       invert: false,
//     });

//   const [transform, setTransform] =
//     useState<RotationOptions>({
//       rotation: 0,
//       flipHorizontal: false,
//       flipVertical: false,
//     });

//   const [resize, setResize] =
//     useState<ResizeOptions>({
//       width: 0,
//       height: 0,
//       keepAspectRatio: true,
//     });

//   const [crop, setCrop] =
//     useState<CropArea | null>(null);

//   const [cropAspectRatio, setCropAspectRatio] =
//     useState("free");

//   const [watermark, setWatermark] =
//     useState<WatermarkOptions>({
//       enabled: false,
//       text: "",
//       opacity: 0.5,
//       fontSize: 32,
//       color: "#ffffff",
//       x: 20,
//       y: 20,
//     });

//       /* --------------------------------
//      Load Image
//   -------------------------------- */

//   const loadImage = useCallback(
//     async (file: File) => {

//       setLoading(true);

//       try {

//         const preview =
//           URL.createObjectURL(file);

//         const engine =
//           new ImageEngine();

//         await engine.load(preview);

//         engineRef.current =
//           engine;

//         setEditorState({
//           file,
//           preview,
//           width: engine.getWidth(),
//           height: engine.getHeight(),
//           fileSize:
//             (
//               file.size /
//               1024 /
//               1024
//             ).toFixed(2) + " MB",
//         });

//         setResize({
//           width: engine.getWidth(),
//           height: engine.getHeight(),
//           keepAspectRatio: true,
//         });

//       } finally {

//         setLoading(false);

//       }

//     },
//     []
//   );

//   /* --------------------------------
//      Render Engine
//   -------------------------------- */

//   const render = useCallback(
//     async () => {

//       if (!engineRef.current)
//         return;

//       setLoading(true);

//       try {

//         const options: ImageEngineOptions = {

//           crop:
//             crop ?? undefined,

//           resize,

//           transform,

//           filters,

//           watermark,

//         };

//         engineRef.current.load(
//   editorState.preview
// );

//         engineRef.current.apply(options);

//         const canvas =
//           engineRef.current.getCanvas();

//         if (
//           canvasRef.current
//         ) {

//           canvasRef.current.width =
//             canvas.width;

//           canvasRef.current.height =
//             canvas.height;

//           const ctx =
//             canvasRef.current.getContext("2d");

//           if (ctx) {

//             ctx.clearRect(
//               0,
//               0,
//               canvas.width,
//               canvas.height
//             );

//             ctx.drawImage(
//               canvas,
//               0,
//               0
//             );

//           }

//         }

//       } finally {

//         setLoading(false);

//       }

//     },
//     [
//       crop,
//       resize,
//       transform,
//       filters,
//       watermark,
//     ]
//   );

//   /* --------------------------------
//      Apply Changes
//   -------------------------------- */

//   const applyChanges =
//     useCallback(
//       async () => {

//         await render();

//       },
//       [render]
//     );

//       /* --------------------------------
//      Rotate
//   -------------------------------- */

//   const rotateLeft = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation: prev.rotation - 90,
//     }));

//   };

//   const rotateRight = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation: prev.rotation + 90,
//     }));

//   };

//   const rotate180 = () => {

//     setTransform(prev => ({
//       ...prev,
//       rotation: prev.rotation + 180,
//     }));

//   };

//   /* --------------------------------
//      Flip
//   -------------------------------- */

//   const toggleFlipHorizontal =
//     () => {

//       setTransform(prev => ({
//         ...prev,
//         flipHorizontal:
//           !prev.flipHorizontal,
//       }));

//     };

//   const toggleFlipVertical =
//     () => {

//       setTransform(prev => ({
//         ...prev,
//         flipVertical:
//           !prev.flipVertical,
//       }));

//     };

//   /* --------------------------------
//      Resize
//   -------------------------------- */

//   const applyResize = (
//     width: number,
//     height: number
//   ) => {

//     setResize(prev => ({
//       ...prev,
//       width,
//       height,
//     }));

//     requestAnimationFrame(
//       applyChanges
//     );

//   };

//   /* --------------------------------
//      Crop
//   -------------------------------- */

//   const applyCrop = (
//     area: CropArea
//   ) => {

//     setCrop(area);

//     requestAnimationFrame(
//       applyChanges
//     );

//   };

//   /* --------------------------------
//      Download
//   -------------------------------- */

//   const downloadImage =
//     useCallback(
//       async () => {

//         if (!engineRef.current)
//           return;

//         await engineRef.current.download();

//       },
//       []
//     );

//       /* --------------------------------
//      Reset Transform
//   -------------------------------- */

//   const resetTransform = () => {

//     setTransform({
//       rotation: 0,
//       flipHorizontal: false,
//       flipVertical: false,
//     });

//     setCrop(null);

//     setCropAspectRatio("free");

//     if (engineRef.current) {

//       setResize({
//         width: engineRef.current.getWidth(),
//         height: engineRef.current.getHeight(),
//         keepAspectRatio: true,
//       });

//     }

//     requestAnimationFrame(
//       applyChanges
//     );

//   };

//   /* --------------------------------
//      Reset Filters
//   -------------------------------- */

//   const resetFilters = () => {

//     setFilters({
//       brightness: 100,
//       contrast: 100,
//       saturation: 100,
//       blur: 0,
//       grayscale: false,
//       sepia: false,
//       invert: false,
//     });

//     requestAnimationFrame(
//       applyChanges
//     );

//   };

//   /* --------------------------------
//      Reset All
//   -------------------------------- */

//   const resetAll = () => {

//     resetTransform();

//     resetFilters();

//     setWatermark({
//       enabled: false,
//       text: "",
//       opacity: 0.5,
//       fontSize: 32,
//       color: "#ffffff",
//       x: 20,
//       y: 20,
//     });

//   };

//   /* --------------------------------
//      Return
//   -------------------------------- */

//   return {

//     /* refs */

//     canvasRef,
//     engineRef,

//     /* state */

//     loading,
//     imageState: editorState,
//     activeTab,

//     filters,
//     transform,
//     resize,
//     crop,
//     watermark,

//     cropAspectRatio,

//     rotation:
//       transform.rotation,

//     flipHorizontal:
//       transform.flipHorizontal,

//     flipVertical:
//       transform.flipVertical,

//     resizeWidth:
//       resize.width,

//     resizeHeight:
//       resize.height,

//     keepAspectRatio:
//       resize.keepAspectRatio,

//     /* setters */

//     setActiveTab,

//     setFilters,

//     setTransform,

//     setResize,

//     setCrop,

//     setWatermark,

//     setCropAspectRatio,

//     setResizeWidth:
//       (width: number) =>
//         setResize(prev => ({
//           ...prev,
//           width,
//         })),

//     setResizeHeight:
//       (height: number) =>
//         setResize(prev => ({
//           ...prev,
//           height,
//         })),

//     setKeepAspectRatio:
//       (value: boolean) =>
//         setResize(prev => ({
//           ...prev,
//           keepAspectRatio: value,
//         })),

//     /* upload */

//     loadImage,

//     /* actions */

//     applyChanges,
//     applyResize,
//     applyCrop,

//     rotateLeft,
//     rotateRight,
//     rotate180,

//     toggleFlipHorizontal,
//     toggleFlipVertical,

//     downloadImage,

//     resetTransform,
//     resetFilters,
//     resetAll,

//   };

// }

"use client";

import { useCallback, useRef, useState } from "react";

import ImageEngine from "../engine/image-engine";

import type {
  CropArea,
  FilterOptions,
  ResizeOptions,
  RotationOptions,
  WatermarkOptions,
  ImageEngineOptions,
} from "../engine/types";

export interface ImageEditorState {
  file: File | null;
  preview: string;
  width: number;
  height: number;
  fileSize: string;
}

export function useImageEditor() {

  const canvasRef =
    useRef<HTMLCanvasElement>(null);

  const engineRef =
    useRef<ImageEngine | null>(null);

  const [loading, setLoading] =
    useState(false);

  const [activeTab, setActiveTab] =
    useState<
      "transform" |
      "effects" |
      "watermark" |
      "metadata"
    >("transform");

  const [imageState, setImageState] =
    useState<ImageEditorState>({
      file: null,
      preview: "",
      width: 0,
      height: 0,
      fileSize: "",
    });

  const [filters, setFilters] =
    useState<FilterOptions>({
      brightness: 100,
      contrast: 100,
      saturation: 100,
      blur: 0,
      grayscale: false,
      sepia: false,
      invert: false,
    });

  const [transform, setTransform] =
    useState<RotationOptions>({
      rotation: 0,
      flipHorizontal: false,
      flipVertical: false,
    });

  const [resize, setResize] =
    useState<ResizeOptions>({
      width: 0,
      height: 0,
      keepAspectRatio: true,
    });

  const [crop, setCrop] =
    useState<CropArea | null>(null);

  const [cropAspectRatio, setCropAspectRatio] =
    useState("free");

  const [watermark, setWatermark] =
    useState<WatermarkOptions>({
      enabled: false,
      text: "",
      opacity: 0.5,
      fontSize: 32,
      color: "#ffffff",
      x: 20,
      y: 20,
    });

      /* =========================================
     Load Image
  ========================================= */

  const loadImage = useCallback(
    async (file: File) => {

      setLoading(true);

      try {

        const preview =
          URL.createObjectURL(file);

        const engine =
          new ImageEngine();

        await engine.load(preview);

        engineRef.current =
          engine;

        setImageState({
          file,
          preview,
          width: engine.getWidth(),
          height: engine.getHeight(),
          fileSize:
            (
              file.size /
              1024 /
              1024
            ).toFixed(2) + " MB",
        });

        setResize({
          width: engine.getWidth(),
          height: engine.getHeight(),
          keepAspectRatio: true,
        });

      } finally {

        setLoading(false);

      }

    },
    []
  );

  /* =========================================
     Render
  ========================================= */

  const render = useCallback(
    async () => {

      if (!engineRef.current)
        return;

      setLoading(true);

      try {

        // const options: ImageEngineOptions = {

        //   crop:
        //     crop ?? undefined,

        //   resize,

        //   transform,

        //   filters,

        //   watermark,

        // };

        const options: ImageEngineOptions = {

  crop: crop ?? undefined,

  resize:
    resize.width > 0 &&
    resize.height > 0
      ? resize
      : undefined,

  transform,

  filters,

  watermark,

};

        engineRef.current
          .apply(options);

        if (canvasRef.current) {

          const source =
            engineRef.current.getCanvas();

          canvasRef.current.width =
            source.width;

          canvasRef.current.height =
            source.height;

          const ctx =
            canvasRef.current.getContext("2d");

          if (ctx) {

            ctx.clearRect(
              0,
              0,
              source.width,
              source.height
            );

            ctx.drawImage(
              source,
              0,
              0
            );

          }

        }

      } finally {

        setLoading(false);

      }

    },
    [
      crop,
      resize,
      transform,
      filters,
      watermark,
    ]
  );

  /* =========================================
     Apply Changes
  ========================================= */

  const applyChanges =
    useCallback(async () => {

      await render();

    }, [render]);

      /* =========================================
     Rotate
  ========================================= */

  const rotateLeft = () =>
    setTransform(prev => ({
      ...prev,
      rotation:
        prev.rotation - 90,
    }));

  const rotateRight = () =>
    setTransform(prev => ({
      ...prev,
      rotation:
        prev.rotation + 90,
    }));

  const rotate180 = () =>
    setTransform(prev => ({
      ...prev,
      rotation:
        prev.rotation + 180,
    }));

  /* =========================================
     Flip
  ========================================= */

  const toggleFlipHorizontal =
    () =>
      setTransform(prev => ({
        ...prev,
        flipHorizontal:
          !prev.flipHorizontal,
      }));

  const toggleFlipVertical =
    () =>
      setTransform(prev => ({
        ...prev,
        flipVertical:
          !prev.flipVertical,
      }));

  /* =========================================
     Resize
  ========================================= */

  const applyResize = (
    width: number,
    height: number
  ) => {

    setResize(prev => ({
      ...prev,
      width,
      height,
    }));

  };

  /* =========================================
     Crop
  ========================================= */

  const applyCrop = (
    area: CropArea
  ) => {

    setCrop(area);

  };

  /* =========================================
     Download
  ========================================= */

  const downloadImage =
    async () => {

      if (!engineRef.current)
        return;

      await engineRef.current.download();

    };

  /* =========================================
     Reset Transform
  ========================================= */

  const resetTransform =
    () => {

      setTransform({
        rotation: 0,
        flipHorizontal: false,
        flipVertical: false,
      });

      setCrop(null);

      if (
        engineRef.current
      ) {

        setResize({
          width:
            engineRef.current.getWidth(),
          height:
            engineRef.current.getHeight(),
          keepAspectRatio: true,
        });

      }

    };

  /* =========================================
     Reset Filters
  ========================================= */

  const resetFilters =
    () => {

      setFilters({
        brightness: 100,
        contrast: 100,
        saturation: 100,
        blur: 0,
        grayscale: false,
        sepia: false,
        invert: false,
      });

    };

  /* =========================================
     Reset All
  ========================================= */

  const resetAll =
    () => {

      resetTransform();

      resetFilters();

      setWatermark({
        enabled: false,
        text: "",
        opacity: 0.5,
        fontSize: 32,
        color: "#ffffff",
        x: 20,
        y: 20,
      });

    };

      /* =========================================
     Return
  ========================================= */

  return {

    /* refs */

    canvasRef,
    engineRef,

    /* loading */

    loading,

    /* tabs */

    activeTab,
    setActiveTab,

    /* image */

    imageState,

    /* editor state */

    filters,
    transform,
    resize,
    crop,
    watermark,

    /* setters */

    setFilters,
    setTransform,
    setResize,
    setCrop,
    setWatermark,

    /* upload */

    loadImage,

    /* apply */

    applyChanges,
    applyResize,
    applyCrop,

    /* rotate */

    rotateLeft,
    rotateRight,
    rotate180,

    /* flip */

    toggleFlipHorizontal,
    toggleFlipVertical,

    /* download */

    downloadImage,

    /* reset */

    resetTransform,
    resetFilters,
    resetAll,

    /* =====================================
       Compatibility (Panels)
    ===================================== */

    rotation:
      transform.rotation,

    flipHorizontal:
      transform.flipHorizontal,

    flipVertical:
      transform.flipVertical,

    cropAspectRatio,

    setCropAspectRatio,

    resizeWidth:
      resize.width,

    resizeHeight:
      resize.height,

    setResizeWidth:
      (width: number) =>
        setResize(prev => ({
          ...prev,
          width,
        })),

    setResizeHeight:
      (height: number) =>
        setResize(prev => ({
          ...prev,
          height,
        })),

    keepAspectRatio:
      resize.keepAspectRatio,

    setKeepAspectRatio:
      (value: boolean) =>
        setResize(prev => ({
          ...prev,
          keepAspectRatio: value,
        })),

  };

}