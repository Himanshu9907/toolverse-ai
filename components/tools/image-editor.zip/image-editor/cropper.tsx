"use client";

import Cropper from "react-easy-crop";

interface ImageCropperProps {
  image: string;

  crop: { x: number; y: number };

  zoom: number;

  aspect: number | undefined;

  onCropChange: (crop: { x: number; y: number }) => void;

  onZoomChange: (zoom: number) => void;

  onCropComplete: (
    croppedArea: any,
    croppedAreaPixels: any
  ) => void;
}

export function ImageCropper({
  image,
  crop,
  zoom,
  aspect,
  onCropChange,
  onZoomChange,
  onCropComplete,
}: ImageCropperProps) {
  return (
    <div className="relative h-[600px] w-full overflow-hidden rounded-2xl bg-black">

      <Cropper
        image={image}
        crop={crop}
        zoom={zoom}
        aspect={aspect}
        cropShape="rect"
        showGrid
        objectFit="contain"
        onCropChange={onCropChange}
        onZoomChange={onZoomChange}
        onCropComplete={onCropComplete}
      />

    </div>
  );
}