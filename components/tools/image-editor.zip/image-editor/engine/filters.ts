// import type { FilterOptions } from "./types";

// /* --------------------------------
//    Apply Filters
// -------------------------------- */

// export function applyFilters(

//   canvas: HTMLCanvasElement,

//   filters: FilterOptions

// ) {

//   const ctx = canvas.getContext("2d");

//   if (!ctx) return canvas;

//   const imageData = ctx.getImageData(

//     0,

//     0,

//     canvas.width,

//     canvas.height

//   );

//   const data = imageData.data;

//   /* -----------------------------
//      Brightness
//   ------------------------------ */

//   const brightness =
//     filters.brightness / 100;

//   /* -----------------------------
//      Contrast
//   ------------------------------ */

//   const contrast =
//     filters.contrast / 100;

//   const factor =
//     (259 * (contrast * 255 + 255)) /
//     (255 * (259 - contrast * 255));

//   /* -----------------------------
//      Pixel Loop
//   ------------------------------ */

//   for (
//     let i = 0;
//     i < data.length;
//     i += 4
//   ) {

//     let r = data[i];

//     let g = data[i + 1];

//     let b = data[i + 2];

//     /* Brightness */

//     r *= brightness;

//     g *= brightness;

//     b *= brightness;

//     /* Contrast */

//     r =
//       factor * (r - 128) + 128;

//     g =
//       factor * (g - 128) + 128;

//     b =
//       factor * (b - 128) + 128;

//     /* Grayscale */

//     if (filters.grayscale) {

//       const avg =
//         (r + g + b) / 3;

//       r = avg;

//       g = avg;

//       b = avg;

//     }

//     /* Sepia */

//     if (filters.sepia) {

//       const nr =
//         r * 0.393 +
//         g * 0.769 +
//         b * 0.189;

//       const ng =
//         r * 0.349 +
//         g * 0.686 +
//         b * 0.168;

//       const nb =
//         r * 0.272 +
//         g * 0.534 +
//         b * 0.131;

//       r = nr;

//       g = ng;

//       b = nb;

//     }

//     /* Invert */

//     if (filters.invert) {

//       r = 255 - r;

//       g = 255 - g;

//       b = 255 - b;

//     }

//     /* Clamp */

//     data[i] = Math.max(
//       0,
//       Math.min(255, r)
//     );

//     data[i + 1] = Math.max(
//       0,
//       Math.min(255, g)
//     );

//     data[i + 2] = Math.max(
//       0,
//       Math.min(255, b)
//     );

//   }

//   ctx.putImageData(

//     imageData,

//     0,

//     0

//   );

//   /* -----------------------------
//      Canvas Filters
//   ------------------------------ */

//   if (
//     filters.blur > 0 ||
//     filters.saturation !== 100
//   ) {

//     const temp =
//       document.createElement(
//         "canvas"
//       );

//     temp.width = canvas.width;

//     temp.height = canvas.height;

//     const tctx =
//       temp.getContext("2d");

//     if (!tctx) return canvas;

//     tctx.filter = `
//       blur(${filters.blur}px)
//       saturate(${filters.saturation}%)
//     `;

//     tctx.drawImage(
//       canvas,
//       0,
//       0
//     );

//     ctx.clearRect(
//       0,
//       0,
//       canvas.width,
//       canvas.height
//     );

//     ctx.drawImage(
//       temp,
//       0,
//       0
//     );

//   }

//   return canvas;

// }

import type { FilterOptions } from "./types";

/* =========================================================
   Apply Filters
========================================================= */

export function applyFilters(
  canvas: HTMLCanvasElement,
  options: FilterOptions
): HTMLCanvasElement {

  const output =
    document.createElement("canvas");

  output.width =
    canvas.width;

  output.height =
    canvas.height;

  const ctx =
    output.getContext("2d");

  if (!ctx)
    return canvas;

  const filter = [

    `brightness(${options.brightness}%)`,

    `contrast(${options.contrast}%)`,

    `saturate(${options.saturation}%)`,

    `blur(${options.blur}px)`,

    options.grayscale
      ? "grayscale(100%)"
      : "grayscale(0%)",

    options.sepia
      ? "sepia(100%)"
      : "sepia(0%)",

    options.invert
      ? "invert(100%)"
      : "invert(0%)",

  ].join(" ");

  ctx.filter = filter;

  ctx.drawImage(
    canvas,
    0,
    0
  );

  ctx.filter = "none";

  return output;

}