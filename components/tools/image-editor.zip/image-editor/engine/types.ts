// export interface CropArea {
//   x: number;
//   y: number;
//   width: number;
//   height: number;
// }

// export interface ResizeOptions {
//   width: number;
//   height: number;
//   keepAspectRatio: boolean;
// }

// export interface RotationOptions {
//   rotation: number;
//   flipHorizontal: boolean;
//   flipVertical: boolean;
// }

// export interface FilterOptions {
//   brightness: number;
//   contrast: number;
//   saturation: number;
//   blur: number;
//   grayscale: boolean;
//   sepia: boolean;
//   invert: boolean;
// }

// export interface WatermarkOptions {
//   enabled: boolean;
//   text?: string;
//   opacity: number;
//   fontSize: number;
//   color: string;
//   x: number;
//   y: number;
// }

// export interface ImageEngineOptions {
//   crop?: CropArea;

//   resize?: ResizeOptions;

//   transform?: RotationOptions;

//   filters?: FilterOptions;

//   watermark?: WatermarkOptions;

//   mimeType?: string;

//   quality?: number;
// }

/* =========================================================
   Core Geometry
========================================================= */

export interface CropArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

/* =========================================================
   Resize
========================================================= */

export interface ResizeOptions {
  width: number;
  height: number;
  keepAspectRatio: boolean;
}

/* =========================================================
   Transform
========================================================= */

export interface TransformOptions {
  rotation: number;
  flipHorizontal: boolean;
  flipVertical: boolean;
}

/* =========================================================
   Filters
========================================================= */

export interface FilterOptions {
  brightness: number;
  contrast: number;
  saturation: number;
  blur: number;
  grayscale: boolean;
  sepia: boolean;
  invert: boolean;
}

/* =========================================================
   Watermark
========================================================= */

export interface WatermarkOptions {
  enabled: boolean;

  text?: string;

  image?: HTMLImageElement;

  opacity: number;

  fontSize: number;

  color: string;

  x: number;

  y: number;
}

/* =========================================================
   Engine Apply Options
========================================================= */

export interface ImageEngineOptions {

  crop?: CropArea;

  resize?: ResizeOptions;

  transform?: TransformOptions;

  filters?: FilterOptions;

  watermark?: WatermarkOptions;

}

/* =========================================================
   Engine State
========================================================= */

export interface EngineState {

  width: number;

  height: number;

  canvas: HTMLCanvasElement;

}

/* =========================================================
   Editor State
========================================================= */

export interface ImageEditorState {

  file: File | null;

  preview: string;

  width: number;

  height: number;

  fileSize: string;

}