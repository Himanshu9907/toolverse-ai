// import { createCanvas } from "./canvas";

// import type {
//   CropArea,
//   RotationOptions,
// } from "./types";

// /* --------------------------------
//    Crop Image
// -------------------------------- */

// export function cropImage(
//   image: HTMLImageElement,
//   crop: CropArea
// ) {

//   const { canvas, ctx } =
//     createCanvas(
//       crop.width,
//       crop.height
//     );

//   ctx.drawImage(
//     image,

//     crop.x,
//     crop.y,

//     crop.width,
//     crop.height,

//     0,
//     0,

//     crop.width,
//     crop.height
//   );

//   return canvas;

// }

// /* --------------------------------
//    Resize
// -------------------------------- */

// export function resizeCanvas(
//   source: HTMLCanvasElement,

//   width: number,

//   height: number
// ) {

//   const { canvas, ctx } =
//     createCanvas(width, height);

//   ctx.drawImage(
//     source,

//     0,
//     0,

//     width,
//     height
//   );

//   return canvas;

// }

// /* --------------------------------
//    Rotate + Flip
// -------------------------------- */

// export function transformCanvas(

//   source: HTMLCanvasElement,

//   options: RotationOptions

// ) {

//   const radians =
//     (options.rotation * Math.PI) /
//     180;

//   const swap =
//     Math.abs(options.rotation % 180) ===
//     90;

//   const width = swap
//     ? source.height
//     : source.width;

//   const height = swap
//     ? source.width
//     : source.height;

//   const { canvas, ctx } =
//     createCanvas(width, height);

//   ctx.translate(
//     width / 2,
//     height / 2
//   );

//   ctx.rotate(radians);

//   ctx.scale(

//     options.flipHorizontal
//       ? -1
//       : 1,

//     options.flipVertical
//       ? -1
//       : 1

//   );

//   ctx.drawImage(

//     source,

//     -source.width / 2,

//     -source.height / 2

//   );

//   return canvas;

// }

// /* --------------------------------
//    Clone Canvas
// -------------------------------- */

// export function cloneCanvas(
//   source: HTMLCanvasElement
// ) {

//   const { canvas, ctx } =
//     createCanvas(
//       source.width,
//       source.height
//     );

//   ctx.drawImage(
//     source,
//     0,
//     0
//   );

//   return canvas;

// }

import type {
  CropArea,
  ResizeOptions,
  TransformOptions,
} from "./types";

/* =========================================================
   Crop
========================================================= */

export function cropCanvas(
  canvas: HTMLCanvasElement,
  area: CropArea
): HTMLCanvasElement {

  const output =
    document.createElement("canvas");

  output.width = area.width;

  output.height = area.height;

  const ctx =
    output.getContext("2d");

  if (!ctx)
    return canvas;

  ctx.drawImage(
    canvas,
    area.x,
    area.y,
    area.width,
    area.height,
    0,
    0,
    area.width,
    area.height
  );

  return output;

}

/* =========================================================
   Resize
========================================================= */

export function resizeCanvas(
  canvas: HTMLCanvasElement,
  options: ResizeOptions
): HTMLCanvasElement {

  const output =
    document.createElement("canvas");

  output.width =
    options.width;

  output.height =
    options.height;

  const ctx =
    output.getContext("2d");

  if (!ctx)
    return canvas;

  ctx.drawImage(
    canvas,
    0,
    0,
    options.width,
    options.height
  );

  return output;

}

/* =========================================================
   Rotate + Flip
========================================================= */

export function transformCanvas(
  canvas: HTMLCanvasElement,
  options: TransformOptions
): HTMLCanvasElement {

  const radians =
    options.rotation *
    Math.PI /
    180;

  const swap =
    Math.abs(
      options.rotation
    ) % 180 === 90;

  const output =
    document.createElement("canvas");

  output.width =
    swap
      ? canvas.height
      : canvas.width;

  output.height =
    swap
      ? canvas.width
      : canvas.height;

  const ctx =
    output.getContext("2d");

  if (!ctx)
    return canvas;

  ctx.save();

  ctx.translate(
    output.width / 2,
    output.height / 2
  );

  ctx.rotate(radians);

  ctx.scale(
    options.flipHorizontal
      ? -1
      : 1,

    options.flipVertical
      ? -1
      : 1
  );

  ctx.drawImage(
    canvas,
    -canvas.width / 2,
    -canvas.height / 2
  );

  ctx.restore();

  return output;

}