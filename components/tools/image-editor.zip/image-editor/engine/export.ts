// export async function canvasToBlob(

//   canvas: HTMLCanvasElement,

//   mimeType = "image/png",

//   quality = 1

// ): Promise<Blob> {

//   return new Promise(

//     (resolve, reject) => {

//       canvas.toBlob(

//         (blob) => {

//           if (!blob) {

//             reject(

//               new Error(

//                 "Unable to export image."

//               )

//             );

//             return;

//           }

//           resolve(blob);

//         },

//         mimeType,

//         quality

//       );

//     }

//   );

// }

// export function downloadBlob(

//   blob: Blob,

//   filename = "toolverse-image.png"

// ) {

//   const url =
//     URL.createObjectURL(blob);

//   const a =
//     document.createElement("a");

//   a.href = url;

//   a.download = filename;

//   document.body.appendChild(a);

//   a.click();

//   document.body.removeChild(a);

//   URL.revokeObjectURL(url);

// }

// export async function exportCanvas(

//   canvas: HTMLCanvasElement,

//   filename = "toolverse-image.png",

//   mimeType = "image/png",

//   quality = 1

// ) {

//   const blob =
//     await canvasToBlob(

//       canvas,

//       mimeType,

//       quality

//     );

//   downloadBlob(

//     blob,

//     filename

//   );

// }

/* =========================================================
   Canvas -> Blob
========================================================= */

export function canvasToBlob(
  canvas: HTMLCanvasElement,
  mimeType: string = "image/png",
  quality: number = 1
): Promise<Blob> {

  return new Promise((resolve, reject) => {

    canvas.toBlob(

      (blob) => {

        if (!blob) {

          reject(
            new Error(
              "Failed to export image."
            )
          );

          return;

        }

        resolve(blob);

      },

      mimeType,

      quality

    );

  });

}

/* =========================================================
   Canvas -> DataURL
========================================================= */

export function canvasToDataURL(
  canvas: HTMLCanvasElement,
  mimeType: string = "image/png",
  quality: number = 1
): string {

  return canvas.toDataURL(
    mimeType,
    quality
  );

}

/* =========================================================
   Download Canvas
========================================================= */

export async function downloadCanvas(
  canvas: HTMLCanvasElement,
  filename: string = "toolverse-image.png",
  mimeType: string = "image/png",
  quality: number = 1
): Promise<void> {

  const blob =
    await canvasToBlob(
      canvas,
      mimeType,
      quality
    );

  const url =
    URL.createObjectURL(blob);

  const link =
    document.createElement("a");

  link.href = url;

  link.download = filename;

  document.body.appendChild(link);

  link.click();

  document.body.removeChild(link);

  URL.revokeObjectURL(url);

}