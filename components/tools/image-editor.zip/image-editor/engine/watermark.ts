// interface WatermarkOptions {

//   enabled: boolean;

//   text?: string;

//   opacity: number;

//   fontSize: number;

//   color: string;

//   x: number;

//   y: number;

// }

// export function applyWatermark(

//   canvas: HTMLCanvasElement,

//   options: WatermarkOptions

// ) {

//   if (!options.enabled)
//     return canvas;

//   const ctx =
//     canvas.getContext("2d");

//   if (!ctx)
//     return canvas;

//   ctx.save();

//   ctx.globalAlpha =
//     options.opacity;

//   ctx.fillStyle =
//     options.color;

//   ctx.font =
//     `bold ${options.fontSize}px sans-serif`;

//   ctx.textAlign = "left";

//   ctx.textBaseline = "top";

//   ctx.fillText(

//     options.text || "ToolVerse",

//     options.x,

//     options.y

//   );

//   ctx.restore();

//   return canvas;

// }

import type { WatermarkOptions } from "./types";

/* =========================================================
   Apply Watermark
========================================================= */

export function applyWatermark(
  canvas: HTMLCanvasElement,
  options: WatermarkOptions
): HTMLCanvasElement {

  const output =
    document.createElement("canvas");

  output.width =
    canvas.width;

  output.height =
    canvas.height;

  const ctx =
    output.getContext("2d");

  if (!ctx)
    return canvas;

  /* Original Image */

  ctx.drawImage(
    canvas,
    0,
    0
  );

  if (!options.enabled)
    return output;

  ctx.globalAlpha =
    options.opacity;

  /* --------------------------------
     Image Watermark
  -------------------------------- */

  if (options.image) {

    ctx.drawImage(
      options.image,
      options.x,
      options.y
    );

  }

  /* --------------------------------
     Text Watermark
  -------------------------------- */

  else if (
    options.text &&
    options.text.trim() !== ""
  ) {

    ctx.fillStyle =
      options.color;

    ctx.font =
      `${options.fontSize}px sans-serif`;

    ctx.textBaseline =
      "top";

    ctx.fillText(
      options.text,
      options.x,
      options.y
    );

  }

  ctx.globalAlpha = 1;

  return output;

}