// export function createCanvas(
//   width: number,
//   height: number
// ) {
//   const canvas =
//     document.createElement("canvas");

//   canvas.width = width;

//   canvas.height = height;

//   const ctx =
//     canvas.getContext("2d");

//   if (!ctx) {
//     throw new Error(
//       "Canvas context not available."
//     );
//   }

//   return {
//     canvas,
//     ctx,
//   };
// }

// export function loadImage(
//   src: string
// ): Promise<HTMLImageElement> {
//   return new Promise(
//     (resolve, reject) => {

//       const image = new Image();

//       image.crossOrigin =
//         "anonymous";

//       image.onload = () =>
//         resolve(image);

//       image.onerror = reject;

//       image.src = src;

//     }
//   );
// }

// export function canvasToBlob(
//   canvas: HTMLCanvasElement,
//   mimeType = "image/png",
//   quality = 1
// ): Promise<Blob> {

//   return new Promise(
//     (resolve, reject) => {

//       canvas.toBlob(
//         (blob) => {

//           if (!blob) {
//             reject(
//               new Error(
//                 "Failed to create blob."
//               )
//             );
//             return;
//           }

//           resolve(blob);

//         },
//         mimeType,
//         quality
//       );

//     }
//   );

// }

// export function downloadBlob(
//   blob: Blob,
//   filename: string
// ) {

//   const url =
//     URL.createObjectURL(blob);

//   const a =
//     document.createElement("a");

//   a.href = url;

//   a.download = filename;

//   document.body.appendChild(a);

//   a.click();

//   document.body.removeChild(a);

//   URL.revokeObjectURL(url);

// }

/* =========================================================
   Canvas Utilities
========================================================= */

export async function loadImage(
  src: string
): Promise<HTMLImageElement> {

  return new Promise((resolve, reject) => {

    const image = new Image();

    image.crossOrigin = "anonymous";

    image.onload = () => resolve(image);

    image.onerror = reject;

    image.src = src;

  });

}

/* =========================================================
   Create Canvas
========================================================= */

export function createCanvas(
  width: number,
  height: number
): HTMLCanvasElement {

  const canvas =
    document.createElement("canvas");

  canvas.width = width;

  canvas.height = height;

  return canvas;

}

/* =========================================================
   Clone Canvas
========================================================= */

export function cloneCanvas(
  source: HTMLCanvasElement
): HTMLCanvasElement {

  const canvas =
    createCanvas(
      source.width,
      source.height
    );

  const ctx =
    canvas.getContext("2d");

  if (ctx) {

    ctx.drawImage(
      source,
      0,
      0
    );

  }

  return canvas;

}

/* =========================================================
   Image -> Canvas
========================================================= */

export function imageToCanvas(
  image: HTMLImageElement
): HTMLCanvasElement {

  const canvas =
    createCanvas(
      image.width,
      image.height
    );

  const ctx =
    canvas.getContext("2d");

  if (ctx) {

    ctx.drawImage(
      image,
      0,
      0
    );

  }

  return canvas;

}