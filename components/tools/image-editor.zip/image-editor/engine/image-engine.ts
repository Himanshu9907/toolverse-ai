// import { loadImage } from "./canvas";

// import {
//   cropImage,
//   resizeCanvas,
//   transformCanvas,
//   cloneCanvas,
// } from "./transforms";

// import { applyFilters } from "./filters";

// import { applyWatermark } from "./watermark";

// import { canvasToBlob } from "./export";

// import type {
//   ImageEngineOptions,
//   FilterOptions,
//   RotationOptions,
//   ResizeOptions,
//   CropArea,
//   WatermarkOptions,
// } from "./types";

// export class ImageEngine {

//   private image!: HTMLImageElement;

//   private canvas!: HTMLCanvasElement;

//   async load(
//     imageSrc: string
//   ) {

//     this.image =
//       await loadImage(imageSrc);

//     this.canvas =
//       cropImage(
//         this.image,
//         {
//           x: 0,
//           y: 0,
//           width: this.image.width,
//           height: this.image.height,
//         }
//       );

//     return this;

//   }

//   getCanvas() {

//     return this.canvas;

//   }

//   getWidth() {

//     return this.canvas.width;

//   }

//   getHeight() {

//     return this.canvas.height;

//   }

// //   clone() {

// //     this.canvas =
// //       cloneCanvas(
// //         this.canvas
// //       );

// //     return this;

// //   }

// clone() {

//     const cloned =
//       cloneCanvas(
//         this.canvas
//       );

//     this.canvas =
//       cloned;

//     return this;

// }

//     /* --------------------------------
//      Crop
//   -------------------------------- */

// //   crop(
// //     area: CropArea
// //   ) {

// //     this.canvas =
// //       cropImage(
// //         this.image,
// //         area
// //       );

// //     return this;

// //   }

// crop(
//   area: CropArea
// ) {

//   const source = new Image();

//   source.src =
//     this.canvas.toDataURL();

//   const canvas =
//     document.createElement("canvas");

//   canvas.width =
//     this.canvas.width;

//   canvas.height =
//     this.canvas.height;

//   const ctx =
//     canvas.getContext("2d");

//   if (!ctx) return this;

//   ctx.drawImage(
//     source,
//     0,
//     0
//   );

//   this.canvas =
//     cropImage(
//       source,
//       area
//     );

//   return this;

// }

//   /* --------------------------------
//      Resize
//   -------------------------------- */

//   resize(
//     options: ResizeOptions
//   ) {

//     this.canvas =
//       resizeCanvas(

//         this.canvas,

//         options.width,

//         options.height

//       );

//     return this;

//   }

//   /* --------------------------------
//      Resize By Scale
//   -------------------------------- */

//   resizeByScale(
//     scale: number
//   ) {

//     const width =
//       Math.round(
//         this.canvas.width *
//         scale
//       );

//     const height =
//       Math.round(
//         this.canvas.height *
//         scale
//       );

//     this.canvas =
//       resizeCanvas(

//         this.canvas,

//         width,

//         height

//       );

//     return this;

//   }

//   /* --------------------------------
//      Reset
//   -------------------------------- */

//   reset() {

//     this.canvas =
//       cropImage(
//         this.image,
//         {
//           x: 0,
//           y: 0,
//           width: this.image.width,
//           height: this.image.height,
//         }
//       );

//     return this;

//   }
//     /* --------------------------------
//      Rotate
//   -------------------------------- */

//   rotate(
//     degrees: number
//   ) {

//     const transform: RotationOptions = {

//       rotation: degrees,

//       flipHorizontal: false,

//       flipVertical: false,

//     };

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         transform
//       );

//     return this;

//   }

//   /* --------------------------------
//      Flip Horizontal
//   -------------------------------- */

//   flipHorizontal() {

//     const transform: RotationOptions = {

//       rotation: 0,

//       flipHorizontal: true,

//       flipVertical: false,

//     };

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         transform
//       );

//     return this;

//   }

//   /* --------------------------------
//      Flip Vertical
//   -------------------------------- */

//   flipVertical() {

//     const transform: RotationOptions = {

//       rotation: 0,

//       flipHorizontal: false,

//       flipVertical: true,

//     };

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         transform
//       );

//     return this;

//   }

//   /* --------------------------------
//      Transform
//   -------------------------------- */

//   transform(
//     options: RotationOptions
//   ) {

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         options
//       );

//     return this;

//   }
//     /* --------------------------------
//      Filters
//   -------------------------------- */

//   filters(
//     options: FilterOptions
//   ) {

//     this.canvas =
//       applyFilters(
//         this.canvas,
//         options
//       );

//     return this;

//   }

//   /* --------------------------------
//      Watermark
//   -------------------------------- */

//   watermark(
//     options: WatermarkOptions
//   ) {

//     this.canvas =
//       applyWatermark(
//         this.canvas,
//         options
//       );

//     return this;

//   }

//   /* --------------------------------
//      Apply Options
//   -------------------------------- */

//   apply(
//     options: ImageEngineOptions
//   ) {

//     if (options.crop) {

//   this.crop(
//     options.crop
//   );

// }

//     if (options.resize) {

//       this.resize(
//         options.resize
//       );

//     }

//     if (options.transform) {

//       this.transform(
//         options.transform
//       );

//     }

//     if (options.filters) {

//       this.filters(
//         options.filters
//       );

//     }

//     if (
//       options.watermark &&
//       options.watermark.enabled
//     ) {

//       this.watermark(
//         options.watermark
//       );

//     }

//     return this;

//   }
//     /* --------------------------------
//      Export Blob
//   -------------------------------- */

//   async toBlob(
//     mimeType = "image/png",
//     quality = 1
//   ) {

//     return canvasToBlob(
//       this.canvas,
//       mimeType,
//       quality
//     );

//   }

//   /* --------------------------------
//      Export Base64
//   -------------------------------- */

//   toDataURL(
//     mimeType = "image/png",
//     quality = 1
//   ) {

//     return this.canvas.toDataURL(
//       mimeType,
//       quality
//     );

//   }

//   /* --------------------------------
//      Download
//   -------------------------------- */

//   async download(
//     filename = "toolverse-image.png",
//     mimeType = "image/png",
//     quality = 1
//   ) {

//     const blob =
//       await this.toBlob(
//         mimeType,
//         quality
//       );

//     const url =
//       URL.createObjectURL(blob);

//     const a =
//       document.createElement("a");

//     a.href = url;

//     a.download = filename;

//     document.body.appendChild(a);

//     a.click();

//     document.body.removeChild(a);

//     URL.revokeObjectURL(url);

//     return this;

//   }

//   /* --------------------------------
//      Process
//   -------------------------------- */

//   async process(
//     imageSrc: string,
//     options: ImageEngineOptions
//   ) {

//     await this.load(imageSrc);

//     // if (options.crop) {

//     //   this.crop(
//     //     options.crop
//     //   );

//     // }

//     this.apply(options);

//     return this;

//   }

// }

// /* --------------------------------
//    Default Export
// -------------------------------- */

// export default ImageEngine;

// import { loadImage } from "./canvas";

// import {
//   cropImage,
//   resizeCanvas,
//   transformCanvas,
// } from "./transforms";

// import { applyFilters } from "./filters";

// import { applyWatermark } from "./watermark";

// import { canvasToBlob } from "./export";

// import type {
//   CropArea,
//   FilterOptions,
//   ImageEngineOptions,
//   ResizeOptions,
//   RotationOptions,
//   WatermarkOptions,
// } from "./types";

// export class ImageEngine {

//   private image!: HTMLImageElement;

//   private canvas!: HTMLCanvasElement;

//   async load(
//     imageSrc: string
//   ) {

//     this.image =
//       await loadImage(imageSrc);

//     this.canvas =
//       cropImage(
//         this.image,
//         {
//           x: 0,
//           y: 0,
//           width: this.image.width,
//           height: this.image.height,
//         }
//       );

//     return this;

//   }

//   private resetCanvas() {

//     this.canvas =
//       cropImage(
//         this.image,
//         {
//           x: 0,
//           y: 0,
//           width: this.image.width,
//           height: this.image.height,
//         }
//       );

//   }

//   getCanvas() {

//     return this.canvas;

//   }

//   getWidth() {

//     return this.canvas.width;

//   }

//   getHeight() {

//     return this.canvas.height;

//   }
//     /* --------------------------------
//       Crop
//   -------------------------------- */

//   crop(
//     area: CropArea
//   ) {

//     this.canvas =
//       cropImage(
//         this.canvas,
//         area
//       );

//     return this;

//   }

//   /* --------------------------------
//       Resize
//   -------------------------------- */

//   resize(
//     options: ResizeOptions
//   ) {

//     this.canvas =
//       resizeCanvas(
//         this.canvas,
//         options.width,
//         options.height
//       );

//     return this;

//   }

//   /* --------------------------------
//       Resize By Scale
//   -------------------------------- */

//   resizeByScale(
//     scale: number
//   ) {

//     const width =
//       Math.round(
//         this.canvas.width * scale
//       );

//     const height =
//       Math.round(
//         this.canvas.height * scale
//       );

//     this.canvas =
//       resizeCanvas(
//         this.canvas,
//         width,
//         height
//       );

//     return this;

//   }

//   /* --------------------------------
//       Rotate
//   -------------------------------- */

//   rotate(
//     degrees: number
//   ) {

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         {
//           rotation: degrees,
//           flipHorizontal: false,
//           flipVertical: false,
//         }
//       );

//     return this;

//   }

//   /* --------------------------------
//       Flip Horizontal
//   -------------------------------- */

//   flipHorizontal() {

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         {
//           rotation: 0,
//           flipHorizontal: true,
//           flipVertical: false,
//         }
//       );

//     return this;

//   }

//   /* --------------------------------
//       Flip Vertical
//   -------------------------------- */

//   flipVertical() {

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         {
//           rotation: 0,
//           flipHorizontal: false,
//           flipVertical: true,
//         }
//       );

//     return this;

//   }

//   /* --------------------------------
//       Transform
//   -------------------------------- */

//   transform(
//     options: RotationOptions
//   ) {

//     this.canvas =
//       transformCanvas(
//         this.canvas,
//         options
//       );

//     return this;

//   }

//     /* --------------------------------
//       Filters
//   -------------------------------- */

//   filters(
//     options: FilterOptions
//   ) {

//     this.canvas =
//       applyFilters(
//         this.canvas,
//         options
//       );

//     return this;

//   }

//   /* --------------------------------
//       Watermark
//   -------------------------------- */

//   watermark(
//     options: WatermarkOptions
//   ) {

//     this.canvas =
//       applyWatermark(
//         this.canvas,
//         options
//       );

//     return this;

//   }

//   /* --------------------------------
//       Apply
//   -------------------------------- */

//   apply(
//     options: ImageEngineOptions
//   ) {

//     // Always start from original image
//     this.resetCanvas();

//     // Crop
//     if (options.crop) {

//       this.crop(
//         options.crop
//       );

//     }

//     // Resize
//     if (options.resize) {

//       this.resize(
//         options.resize
//       );

//     }

//     // Rotate / Flip
//     if (options.transform) {

//       this.transform(
//         options.transform
//       );

//     }

//     // Filters
//     if (options.filters) {

//       this.filters(
//         options.filters
//       );

//     }

//     // Watermark
//     if (
//       options.watermark &&
//       options.watermark.enabled
//     ) {

//       this.watermark(
//         options.watermark
//       );

//     }

//     return this;

//   }

//     /* --------------------------------
//       Export Blob
//   -------------------------------- */

//   async toBlob(
//     mimeType = "image/png",
//     quality = 1
//   ) {

//     return await canvasToBlob(
//       this.canvas,
//       mimeType,
//       quality
//     );

//   }

//   /* --------------------------------
//       Export Base64
//   -------------------------------- */

//   toDataURL(
//     mimeType = "image/png",
//     quality = 1
//   ) {

//     return this.canvas.toDataURL(
//       mimeType,
//       quality
//     );

//   }

//   /* --------------------------------
//       Download
//   -------------------------------- */

//   async download(
//     filename = "toolverse-image.png",
//     mimeType = "image/png",
//     quality = 1
//   ) {

//     const blob =
//       await this.toBlob(
//         mimeType,
//         quality
//       );

//     const url =
//       URL.createObjectURL(blob);

//     const a =
//       document.createElement("a");

//     a.href = url;

//     a.download = filename;

//     document.body.appendChild(a);

//     a.click();

//     document.body.removeChild(a);

//     URL.revokeObjectURL(url);

//     return this;

//   }

//   /* --------------------------------
//       Process
//   -------------------------------- */

//   async process(
//     imageSrc: string,
//     options: ImageEngineOptions
//   ) {

//     await this.load(
//       imageSrc
//     );

//     this.apply(
//       options
//     );

//     return this;

//   }

// }

// /* --------------------------------
//     Export
// -------------------------------- */

// export default ImageEngine;

import {
  loadImage,
  imageToCanvas,
} from "./canvas";

import {
  cropCanvas,
  resizeCanvas,
  transformCanvas,
} from "./transforms";

import { applyFilters } from "./filters";
import { applyWatermark } from "./watermark";

import {
  canvasToBlob,
  canvasToDataURL,
  downloadCanvas,
} from "./export";

import type {
  ImageEngineOptions,
  CropArea,
  ResizeOptions,
  TransformOptions,
  FilterOptions,
  WatermarkOptions,
} from "./types";

export class ImageEngine {

  private image!: HTMLImageElement;

  private originalCanvas!: HTMLCanvasElement;

  private canvas!: HTMLCanvasElement;

  async load(
    src: string
  ) {

    this.image =
      await loadImage(src);

    this.originalCanvas =
      imageToCanvas(this.image);

    this.canvas =
      imageToCanvas(this.image);

    return this;

  }

  getCanvas() {

    return this.canvas;

  }

  getWidth() {

    return this.canvas.width;

  }

  getHeight() {

    return this.canvas.height;

  }

  reset() {

    this.canvas =
      imageToCanvas(this.image);

    return this;

  }

    /* =========================================
     Crop
  ========================================= */

  crop(
    area: CropArea
  ) {

    this.canvas =
      cropCanvas(
        this.canvas,
        area
      );

    return this;

  }

  /* =========================================
     Resize
  ========================================= */

  resize(
    options: ResizeOptions
  ) {

    this.canvas =
      resizeCanvas(
        this.canvas,
        options.width,
        options.height
      );

    return this;

  }

  /* =========================================
     Transform
  ========================================= */

  transform(
    options: TransformOptions
  ) {

    this.canvas =
      transformCanvas(
        this.canvas,
        options
      );

    return this;

  }

  /* =========================================
     Filters
  ========================================= */

  filters(
    options: FilterOptions
  ) {

    this.canvas =
      applyFilters(
        this.canvas,
        options
      );

    return this;

  }

  /* =========================================
     Watermark
  ========================================= */

  watermark(
    options: WatermarkOptions
  ) {

    if (!options.enabled) {

      return this;

    }

    this.canvas =
      applyWatermark(
        this.canvas,
        options
      );

    return this;

  }

    /* =========================================
     Apply All Operations
  ========================================= */

  apply(
    options: ImageEngineOptions
  ) {

    this.reset();

    if (options.crop) {

      this.crop(
        options.crop
      );

    }

    if (options.resize) {

      this.resize(
        options.resize
      );

    }

    if (options.transform) {

      this.transform(
        options.transform
      );

    }

    if (options.filters) {

      this.filters(
        options.filters
      );

    }

    if (
      options.watermark &&
      options.watermark.enabled
    ) {

      this.watermark(
        options.watermark
      );

    }

    return this;

  }

    /* =========================================
     Export Blob
  ========================================= */

  async toBlob(
    mimeType = "image/png",
    quality = 1
  ) {

    return canvasToBlob(
      this.canvas,
      mimeType,
      quality
    );

  }

  /* =========================================
     Export Data URL
  ========================================= */

  toDataURL(
    mimeType = "image/png",
    quality = 1
  ) {

    return canvasToDataURL(
      this.canvas,
      mimeType,
      quality
    );

  }

  /* =========================================
     Download
  ========================================= */

  async download(
    filename = "toolverse-image.png",
    mimeType = "image/png",
    quality = 1
  ) {

    await downloadCanvas(
      this.canvas,
      filename,
      mimeType,
      quality
    );

    return this;

  }

}

/* =========================================
   Default Export
========================================= */

export default ImageEngine;