// "use client";

// import { useState } from "react";

// import { UploadZone } from "@/components/shared/upload-zone";
// import { PreviewPanel } from "@/components/shared/preview-panel";

// import {
//   Toolbar,
//   EditorTab,
// } from "./toolbar";

// import { TransformControls } from "./controls/transform-controls";
// import { EffectsControls } from "./controls/effects-controls";
// import { WatermarkControls } from "./controls/watermark-controls";
// import { MetadataPanel } from "./controls/metadata-panel";

// export function ImageEditor() {
//   const [activeTab, setActiveTab] =
//     useState<EditorTab>("transform");

//   const [image, setImage] =
//     useState<File | null>(null);

//   const [preview, setPreview] =
//     useState("");

//   const [width, setWidth] =
//     useState(0);

//   const [height, setHeight] =
//     useState(0);

//   const [fileSize, setFileSize] =
//     useState("");

//   const handleUpload = (file: File) => {
//     setImage(file);

//     const url =
//       URL.createObjectURL(file);

//     setPreview(url);

//     setFileSize(
//       (
//         file.size /
//         1024 /
//         1024
//       ).toFixed(2) + " MB"
//     );

//     const img = new Image();

//     img.src = url;

//     img.onload = () => {
//       setWidth(img.width);
//       setHeight(img.height);
//     };
//   };

//   return (
//     <div className="mx-auto max-w-7xl space-y-8">

//       {/* Upload */}

//       <UploadZone
//         onFileSelect={handleUpload}
//       />

//       {/* Toolbar */}

//       <Toolbar
//         activeTab={activeTab}
//         onTabChange={setActiveTab}
//       />

//       {/* Layout */}

//       <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_380px]">

//         {/* Preview */}

//         <PreviewPanel
//           preview={preview}
//           resizedPreview={preview}
//           image={image}
//           width={width}
//           height={height}
//           fileSize={fileSize}
//         />

//         {/* Controls */}

//         <div className="space-y-6">

//           {activeTab ===
//             "transform" && (
//             <TransformControls />
//           )}

//           {activeTab ===
//             "effects" && (
//             <EffectsControls />
//           )}

//           {activeTab ===
//             "watermark" && (
//             <WatermarkControls />
//           )}

//           {activeTab ===
//             "metadata" && (
//             <MetadataPanel
//               image={image}
//               width={width}
//               height={height}
//               fileSize={fileSize}
//             />
//           )}

//         </div>

//       </div>

//     </div>
//   );
// }

"use client";

import { UploadZone } from "@/components/shared/upload-zone";
import { PreviewPanel } from "@/components/shared/preview-panel";

import { Toolbar } from "./toolbar";
import { TransformControls } from "./controls/transform-controls";
import { EffectsControls } from "./controls/effects-controls";
import { WatermarkControls } from "./controls/watermark-controls";
import { MetadataPanel } from "./controls/metadata-panel";

import { useImageEditor } from "./hooks/use-image-editor";

export function ImageEditor() {
  const editor = useImageEditor();

  return (
    <div className="space-y-8">

      <UploadZone
        onFileSelect={editor.loadImage}
      />

      <Toolbar
        activeTab={editor.activeTab}
        onTabChange={editor.setActiveTab}
      />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_380px]">

        <PreviewPanel
          preview={editor.imageState.preview}
          resizedPreview={editor.imageState.preview}
          image={editor.imageState.file}
          width={editor.imageState.width}
          height={editor.imageState.height}
          fileSize={editor.imageState.fileSize}
        />

        {editor.activeTab === "transform" && (
          <TransformControls editor={editor} />
        )}

        {editor.activeTab === "effects" && (
          <EffectsControls editor={editor} />
        )}

        {editor.activeTab === "watermark" && (
          <WatermarkControls editor={editor} />
        )}

        {editor.activeTab === "metadata" && (
          <MetadataPanel editor={editor} />
        )}

      </div>

      <canvas
        ref={editor.canvasRef}
        className="hidden"
      />

    </div>
  );
}